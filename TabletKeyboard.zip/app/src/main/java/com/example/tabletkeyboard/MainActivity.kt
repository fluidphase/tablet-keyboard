package com.example.tabletkeyboard

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** Setup screen: enable the keyboard, pick it, choose options, and test it. */
class MainActivity : Activity() {

    private fun LinearLayout.addTitle(text: String) {
        val dp = resources.displayMetrics.density
        addView(TextView(context).apply {
            this.text = text
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(0, (16 * dp).toInt(), 0, 0)
        })
    }

    private fun LinearLayout.addChoices(
        prefs: SharedPreferences, title: String, key: String, default: String,
        options: List<Pair<String, String>>
    ) {
        addTitle(title)
        val group = RadioGroup(context).apply { orientation = RadioGroup.VERTICAL }
        val ids = HashMap<Int, String>()
        val current = prefs.getString(key, default)
        for ((value, label) in options) {
            val rb = RadioButton(context).apply {
                id = View.generateViewId()
                text = label
                textSize = 16f
                setTextColor(Color.BLACK)
            }
            ids[rb.id] = value
            group.addView(rb)
            if (value == current) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            ids[checkedId]?.let { prefs.edit().putString(key, it).apply() }
        }
        addView(group)
    }

    private fun LinearLayout.addSwitch(
        prefs: SharedPreferences, label: String, key: String, default: Boolean
    ) {
        addView(CheckBox(context).apply {
            text = label
            textSize = 16f
            setTextColor(Color.BLACK)
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        })
    }

    private fun LinearLayout.addSlider(prefs: SharedPreferences, key: String, max: Int, label: (Int) -> String) {
        val dp = resources.displayMetrics.density
        val tv = TextView(context).apply {
            textSize = 16f
            setTextColor(Color.BLACK)
            text = label(prefs.getInt(key, 0))
        }
        addView(tv)
        addView(SeekBar(context).apply {
            this.max = max
            progress = prefs.getInt(key, 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    tv.text = label(value)
                    prefs.edit().putInt(key, value).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(-1, (40 * dp).toInt()))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (24 * dp).toInt()
        val prefs = getSharedPreferences("kb", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "Tablet Keyboard"
            textSize = 28f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "1) Enable the keyboard\n2) Choose it as your input method\n3) Pick your options\n4) Tap the box at the bottom to test"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad / 2, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Choose keyboard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        root.addChoices(prefs, "Keyboard size", "mode", "big", listOf(
            "big" to "Big mode (full layout)",
            "small" to "Small mode (compact)"
        ))
        root.addChoices(prefs, "Keyboard theme", "theme", "auto", listOf(
            "auto" to "Auto (follow system)",
            "light" to "Light",
            "dark" to "Dark"
        ))

        root.addTitle("Key transparency")
        root.addSlider(prefs, "transparency", 80) { v ->
            if (v == 0) "Solid (0%)" else "See-through: $v%"
        }

        root.addTitle("Number row")
        root.addSwitch(prefs, "Show number row in big mode", "numrow_big", true)
        root.addSwitch(prefs, "Show number row in small mode", "numrow_small", false)

        root.addTitle("Typing help")
        root.addSwitch(prefs, "Show suggestions bar", "suggest", true)
        root.addSwitch(prefs, "Autocorrect (fix typos when you press space)", "autocorrect", true)
        root.addSwitch(prefs, "Show cut/copy/paste icons next to the suggestions", "toolbar_icons", false)
        root.addView(TextView(this).apply {
            text = "Autocorrect uses a built-in English dictionary, so it works offline in any app. " +
                "Tap backspace right after a correction to undo it."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, pad / 4, 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "Changes apply the next time you tap a text field."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, pad / 4, 0, 0)
        })

        root.addView(EditText(this).apply {
            hint = "4. Tap here to test"
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = pad })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
    }
}
