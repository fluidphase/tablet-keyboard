package com.example.tabletkeyboard

import android.content.Context
import kotlin.math.abs
import kotlin.math.hypot

/** typo = the word isn't in the dictionary; confident = safe enough to autocorrect */
class SpellResult(val typo: Boolean, val sugs: List<String>, val confident: Boolean)

/**
 * Offline English spell checker. Uses a bundled dictionary (assets/words.txt, ~160k words)
 * and a list of common words in rough frequency order (assets/common.txt) to rank corrections.
 */
class SpellEngine(private val ctx: Context) {

    @Volatile private var words: HashSet<String>? = null
    private var noSuggest: HashSet<String> = HashSet()
    private val commonRank = HashMap<String, Int>()
    private var common: List<String> = emptyList()

    fun loadAsync() {
        if (words == null) Thread { load() }.start()
    }

    private fun load() {
        try {
            val set = HashSet<String>(230_000)
            val bad = HashSet<String>()
            ctx.assets.open("words.txt").bufferedReader().useLines { lines ->
                for (l in lines) {
                    if (l.isEmpty()) continue
                    if (l[0] == '!') { bad.add(l.substring(1)); set.add(l.substring(1)) } else set.add(l)
                }
            }
            val list = ArrayList<String>()
            ctx.assets.open("common.txt").bufferedReader().useLines { lines ->
                for (raw in lines) {
                    val w = raw.trim()
                    if (w.isNotEmpty() && !commonRank.containsKey(w)) {
                        commonRank[w] = list.size
                        list.add(w)
                        set.add(w)
                    }
                }
            }
            common = list
            noSuggest = bad
            words = set
        } catch (_: Throwable) { }
    }

    /** Check one word (call from a background thread). */
    fun analyze(raw: String): SpellResult {
        val set = words ?: return SpellResult(false, emptyList(), false)
        val w = raw.lowercase()
        if (w.isEmpty()) return SpellResult(false, emptyList(), false)

        FIX[w]?.let { return SpellResult(true, listOf(it), true) }

        if (w.length < 2 || w in set || w.any { it.isDigit() }) {
            return SpellResult(false, completions(w, 3), false)
        }

        val e1 = edits1(w)
        val cands = HashMap<String, Int>()
        for (c in e1) if (c in set && c !in noSuggest) cands[c] = 1
        if (cands.isEmpty() && w.length in 4..12) {
            for (a in e1) {
                for (c in edits1(a)) {
                    if (c in set && c !in noSuggest && !cands.containsKey(c)) cands[c] = 2
                }
            }
        }
        if (cands.isEmpty()) return SpellResult(true, emptyList(), false)

        val ranked = cands.entries.sortedBy { score(w, it.key, it.value) }
        val top = ranked.take(3).map { it.key }
        val best = ranked[0]
        val confident = best.value == 1 || (best.value == 2 && w.length >= 6 && best.key[0] == w[0])
        return SpellResult(true, top, confident)
    }

    private fun completions(w: String, n: Int): List<String> {
        if (w.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        for (c in common) {
            if (c.length > w.length && c.startsWith(w)) {
                out.add(c)
                if (out.size >= n) break
            }
        }
        return out
    }

    private fun edits1(w: String): HashSet<String> {
        val out = HashSet<String>()
        val n = w.length
        for (i in 0 until n) out.add(w.substring(0, i) + w.substring(i + 1))
        for (i in 0 until n - 1) out.add(w.substring(0, i) + w[i + 1] + w[i] + w.substring(i + 2))
        for (i in 0 until n) for (c in ALPHA) if (c != w[i]) out.add(w.substring(0, i) + c + w.substring(i + 1))
        for (i in 0..n) for (c in ALPHA) out.add(w.substring(0, i) + c + w.substring(i))
        return out
    }

    // Lower score = better suggestion
    private fun score(w: String, c: String, dist: Int): Int {
        var sc = dist * 100
        val r = commonRank[c]
        if (r != null) sc -= 70 - minOf(r / 10, 60)
        if (c[0] != w[0]) sc += 25
        if (abs(c.length - w.length) > 1) sc += 10
        if (c.length == w.length) {
            if (c.toCharArray().sorted() == w.toCharArray().sorted()) sc -= 20   // swapped letters
            var diff = -1
            var count = 0
            for (i in c.indices) if (c[i] != w[i]) { count++; diff = i }
            if (count == 1 && near(w[diff], c[diff])) sc -= 15                     // neighbouring key
        }
        return sc
    }

    private fun pos(c: Char): Pair<Float, Float>? {
        for (r in 0..2) {
            val i = ROWS[r].indexOf(c)
            if (i >= 0) return Pair(i + OFFS[r], r.toFloat())
        }
        return null
    }

    private fun near(a: Char, b: Char): Boolean {
        val pa = pos(a) ?: return false
        val pb = pos(b) ?: return false
        return hypot(pa.first - pb.first, pa.second - pb.second) < 1.5f
    }

    companion object {
        private const val ALPHA = "abcdefghijklmnopqrstuvwxyz'"
        private val ROWS = arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        private val OFFS = floatArrayOf(0f, 0.5f, 1.0f)

        // Always-fix list: missing apostrophes, lowercase "i", and a few classic typos
        private val FIX: Map<String, String> = mapOf(
            "i" to "I", "i'm" to "I'm", "i'll" to "I'll", "i've" to "I've", "i'd" to "I'd",
            "im" to "I'm", "ive" to "I've",
            "dont" to "don't", "cant" to "can't", "wont" to "won't", "isnt" to "isn't",
            "didnt" to "didn't", "doesnt" to "doesn't", "wasnt" to "wasn't", "werent" to "weren't",
            "couldnt" to "couldn't", "wouldnt" to "wouldn't", "shouldnt" to "shouldn't",
            "arent" to "aren't", "hasnt" to "hasn't", "havent" to "haven't", "hadnt" to "hadn't",
            "youre" to "you're", "theyre" to "they're", "thats" to "that's", "whats" to "what's",
            "theres" to "there's", "shes" to "she's", "whos" to "who's",
            "teh" to "the", "adn" to "and", "taht" to "that", "thier" to "their", "recieve" to "receive",
            "definately" to "definitely", "seperate" to "separate", "occured" to "occurred",
            "untill" to "until", "wich" to "which", "becuase" to "because", "alot" to "a lot",
            "tomorow" to "tomorrow", "freind" to "friend", "beleive" to "believe", "wierd" to "weird"
        )
    }
}
