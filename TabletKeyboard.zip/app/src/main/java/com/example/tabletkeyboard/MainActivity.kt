package com.example.tabletkeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

/** Setup screen: enable the keyboard, pick it, choose Light / Dark, and test it. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (24 * dp).toInt()
        val prefs = getSharedPreferences("kb", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "Tablet Keyboard"
            textSize = 28f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "1) Enable the keyboard\n2) Choose it as your input method\n3) Pick a theme\n4) Tap the box below to test"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad / 2, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Choose keyboard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        // ----- Theme: Auto / Light / Dark -----
        root.addView(TextView(this).apply {
            text = "3. Keyboard theme"
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(0, pad / 2, 0, 0)
        })
        val options = listOf("auto" to "Auto (follow system)", "light" to "Light", "dark" to "Dark")
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val ids = HashMap<Int, String>()
        val current = prefs.getString("theme", "auto")
        for ((value, label) in options) {
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = label
                textSize = 16f
                setTextColor(Color.BLACK)
            }
            ids[rb.id] = value
            group.addView(rb)
            if (value == current) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            ids[checkedId]?.let { prefs.edit().putString("theme", it).apply() }
        }
        root.addView(group)

        root.addView(EditText(this).apply {
            hint = "4. Tap here to test"
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = pad })
        setContentView(root)
    }
}
