package com.example.tabletkeyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.PopupWindow

private val KEY_GO = Color.parseColor("#0A84FF")

enum class Type { CHAR, DELETE, TAB, CAPS, SHIFT, GO, SPACE, SYMBOLS, EMOJI, MIC, HIDE, DOTCOM, LEFT, RIGHT, INERT, SPACER }
enum class Align { CENTER, LEFT, RIGHT }
enum class Icon { SMILEY, MIC, KEYBOARD, SCISSORS, COPY, PASTE, SHIFT, BACKSPACE, GLOBE, UNDO, REDO }

data class K(
    val base: String,
    val top: String? = null,       // shifted symbol shown above the base (two-line keys)
    val weight: Float = 1f,
    val type: Type = Type.CHAR,
    val align: Align = Align.CENTER,
    val hint: String? = null       // small mode: tiny symbol on top, typed by flicking down
)

private fun letters(s: String) = s.map { K(it.toString()) }
private fun plain(s: String) = s.map { K(it.toString()) }
private fun hinted(chars: String, hints: String) =
    chars.indices.map { K(chars[it].toString(), hint = hints[it].toString()) }

// ---------- Long-press alternates ----------
private val ALTERNATES: Map<String, List<String>> = mapOf(
    "a" to listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā"),
    "e" to listOf("è", "é", "ê", "ë", "ē", "ė", "ę"),
    "i" to listOf("î", "ï", "í", "ī", "į", "ì"),
    "o" to listOf("ô", "ö", "ò", "ó", "œ", "ø", "ō", "õ"),
    "u" to listOf("û", "ü", "ù", "ú", "ū"),
    "y" to listOf("ÿ", "ý"),
    "c" to listOf("ç", "ć", "č"),
    "n" to listOf("ñ", "ń"),
    "s" to listOf("ś", "š", "ß"),
    "z" to listOf("ž", "ź", "ż"),
    "l" to listOf("ł"),
    "$" to listOf("€", "£", "¥", "¢"),
    "-" to listOf("–", "—", "•"),
    "." to listOf("…", "·"),
    "?" to listOf("¿"),
    "!" to listOf("¡"),
    "'" to listOf("‘", "’"),
    "\"" to listOf("“", "”", "«", "»"),
    "&" to listOf("§"),
    "=" to listOf("≠", "≈"),
    "0" to listOf("°"),
    "/" to listOf("\\")
)

// ---------- Light / dark palettes ----------
class Palette(val dark: Boolean) {
    val text = if (dark) Color.WHITE else Color.BLACK
    val bg = if (dark) Color.parseColor("#1E1E21") else Color.parseColor("#D1D3D9")
    val toolbar = if (dark) Color.parseColor("#2A2A2D") else Color.parseColor("#DCDDE2")
    val keyLight = if (dark) Color.parseColor("#6B6B70") else Color.WHITE
    val keyDark = if (dark) Color.parseColor("#47474B") else Color.parseColor("#B9BDC8")
    val pressed = if (dark) Color.parseColor("#8E8E93") else Color.parseColor("#9EA3B0")
    val shadow = if (dark) Color.BLACK else Color.parseColor("#898A8D")
}

// ---------- Icons drawn with Canvas ----------
private fun drawUndoShape(c: Canvas, cx: Float, cy: Float, r: Float, stroke: Paint) {
    val head = Path()
    head.moveTo(cx - r * 0.35f, cy - r * 0.75f)
    head.lineTo(cx - r * 0.8f, cy - r * 0.3f)
    head.lineTo(cx - r * 0.35f, cy + r * 0.15f)
    c.drawPath(head, stroke)
    val body = Path()
    body.moveTo(cx - r * 0.8f, cy - r * 0.3f)
    body.lineTo(cx + r * 0.2f, cy - r * 0.3f)
    body.cubicTo(cx + r * 0.9f, cy - r * 0.3f, cx + r * 0.9f, cy + r * 0.8f, cx + r * 0.2f, cy + r * 0.8f)
    body.lineTo(cx - r * 0.3f, cy + r * 0.8f)
    c.drawPath(body, stroke)
}

fun drawIcon(c: Canvas, icon: Icon, cx: Float, cy: Float, size: Float,
             color: Int, inner: Int, on: Boolean = false, bar: Boolean = false) {
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; this.color = color
        strokeWidth = size * 0.075f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = color }
    val innerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = inner }
    val r = size / 2f
    when (icon) {
        Icon.SMILEY -> {
            c.drawCircle(cx, cy, r * 0.9f, stroke)
            c.drawCircle(cx - r * 0.32f, cy - r * 0.2f, r * 0.09f, fill)
            c.drawCircle(cx + r * 0.32f, cy - r * 0.2f, r * 0.09f, fill)
            c.drawArc(RectF(cx - r * 0.5f, cy - r * 0.35f, cx + r * 0.5f, cy + r * 0.55f), 20f, 140f, false, stroke)
        }
        Icon.MIC -> {
            c.drawRoundRect(RectF(cx - r * 0.28f, cy - r * 0.95f, cx + r * 0.28f, cy + r * 0.2f), r * 0.28f, r * 0.28f, stroke)
            c.drawArc(RectF(cx - r * 0.6f, cy - r * 0.45f, cx + r * 0.6f, cy + r * 0.55f), 0f, 180f, false, stroke)
            c.drawLine(cx, cy + r * 0.55f, cx, cy + r * 0.95f, stroke)
        }
        Icon.KEYBOARD -> {
            c.drawRoundRect(RectF(cx - r, cy - r * 0.7f, cx + r, cy + r * 0.2f), r * 0.12f, r * 0.12f, stroke)
            for (i in 0..4) {
                val x = cx - r * 0.65f + i * r * 0.325f
                c.drawCircle(x, cy - r * 0.45f, r * 0.05f, fill)
                c.drawCircle(x, cy - r * 0.2f, r * 0.05f, fill)
            }
            c.drawLine(cx - r * 0.5f, cy, cx + r * 0.5f, cy, stroke)
            val p = Path()
            p.moveTo(cx - r * 0.25f, cy + r * 0.5f); p.lineTo(cx, cy + r * 0.75f); p.lineTo(cx + r * 0.25f, cy + r * 0.5f)
            c.drawPath(p, stroke)
        }
        Icon.SCISSORS -> {
            c.drawCircle(cx - r * 0.55f, cy + r * 0.55f, r * 0.25f, stroke)
            c.drawCircle(cx + r * 0.55f, cy + r * 0.55f, r * 0.25f, stroke)
            c.drawLine(cx - r * 0.4f, cy + r * 0.35f, cx + r * 0.85f, cy - r * 0.8f, stroke)
            c.drawLine(cx + r * 0.4f, cy + r * 0.35f, cx - r * 0.85f, cy - r * 0.8f, stroke)
        }
        Icon.COPY -> {
            c.drawRoundRect(RectF(cx - r * 0.75f, cy - r * 0.85f, cx + r * 0.2f, cy + r * 0.35f), r * 0.12f, r * 0.12f, stroke)
            c.drawRoundRect(RectF(cx - r * 0.2f, cy - r * 0.35f, cx + r * 0.75f, cy + r * 0.85f), r * 0.12f, r * 0.12f, stroke)
        }
        Icon.PASTE -> {
            c.drawRoundRect(RectF(cx - r * 0.7f, cy - r * 0.75f, cx + r * 0.7f, cy + r * 0.95f), r * 0.15f, r * 0.15f, fill)
            c.drawRoundRect(RectF(cx - r * 0.45f, cy - r * 0.4f, cx + r * 0.45f, cy + r * 0.75f), r * 0.08f, r * 0.08f, innerFill)
            c.drawRoundRect(RectF(cx - r * 0.3f, cy - r * 0.95f, cx + r * 0.3f, cy - r * 0.5f), r * 0.1f, r * 0.1f, fill)
        }
        Icon.SHIFT -> {
            val p = Path()
            p.moveTo(cx, cy - r * 0.85f)
            p.lineTo(cx + r * 0.8f, cy)
            p.lineTo(cx + r * 0.4f, cy)
            p.lineTo(cx + r * 0.4f, cy + r * 0.75f)
            p.lineTo(cx - r * 0.4f, cy + r * 0.75f)
            p.lineTo(cx - r * 0.4f, cy)
            p.lineTo(cx - r * 0.8f, cy)
            p.close()
            if (on) c.drawPath(p, fill)
            c.drawPath(p, stroke)
            if (bar) c.drawLine(cx - r * 0.4f, cy + r * 1.0f, cx + r * 0.4f, cy + r * 1.0f, stroke)
        }
        Icon.BACKSPACE -> {
            val p = Path()
            p.moveTo(cx - r * 1.0f, cy)
            p.lineTo(cx - r * 0.55f, cy - r * 0.6f)
            p.lineTo(cx + r * 0.95f, cy - r * 0.6f)
            p.lineTo(cx + r * 0.95f, cy + r * 0.6f)
            p.lineTo(cx - r * 0.55f, cy + r * 0.6f)
            p.close()
            c.drawPath(p, stroke)
            c.drawLine(cx - r * 0.05f, cy - r * 0.25f, cx + r * 0.5f, cy + r * 0.25f, stroke)
            c.drawLine(cx - r * 0.05f, cy + r * 0.25f, cx + r * 0.5f, cy - r * 0.25f, stroke)
        }
        Icon.GLOBE -> {
            c.drawCircle(cx, cy, r * 0.9f, stroke)
            c.drawOval(RectF(cx - r * 0.4f, cy - r * 0.9f, cx + r * 0.4f, cy + r * 0.9f), stroke)
            c.drawLine(cx - r * 0.9f, cy, cx + r * 0.9f, cy, stroke)
            c.drawLine(cx - r * 0.7f, cy - r * 0.45f, cx + r * 0.7f, cy - r * 0.45f, stroke)
            c.drawLine(cx - r * 0.7f, cy + r * 0.45f, cx + r * 0.7f, cy + r * 0.45f, stroke)
        }
        Icon.UNDO -> drawUndoShape(c, cx, cy, r, stroke)
        Icon.REDO -> {
            c.save()
            c.scale(-1f, 1f, cx, cy)
            drawUndoShape(c, cx, cy, r, stroke)
            c.restore()
        }
    }
}

class IconView(
    ctx: Context, private val icon: Icon, private val color: Int, private val inner: Int,
    private val onTap: () -> Unit
) : View(ctx) {
    init { setOnClickListener { onTap() } }
    override fun onDraw(c: Canvas) {
        drawIcon(c, icon, width / 2f, height / 2f, minOf(width, height) * 0.6f, color, inner)
    }
}

// ---------- The popup bubble shown on long-press ----------
class AltView(
    ctx: Context, val opts: List<String>,
    val cellW: Float, val cellH: Float, private val pal: Palette
) : View(ctx) {
    var selected = 0
    val pad = cellH * 0.08f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rad = cellH * 0.18f
        p.style = Paint.Style.FILL; p.color = pal.keyLight
        c.drawRoundRect(0f, 0f, w, h, rad, rad, p)
        p.style = Paint.Style.STROKE; p.color = pal.shadow; p.strokeWidth = 2f
        c.drawRoundRect(1f, 1f, w - 1f, h - 1f, rad, rad, p)
        for (i in opts.indices) {
            val left = pad + i * cellW
            if (i == selected) {
                p.style = Paint.Style.FILL; p.color = KEY_GO
                c.drawRoundRect(left, pad, left + cellW, pad + cellH, cellH * 0.14f, cellH * 0.14f, p)
            }
            p.style = Paint.Style.FILL
            p.color = if (i == selected) Color.WHITE else pal.text
            p.textSize = cellH * 0.5f
            p.textAlign = Paint.Align.CENTER
            c.drawText(opts[i], left + cellW / 2, pad + cellH / 2 - (p.ascent() + p.descent()) / 2, p)
        }
    }
}

class KeyboardService : InputMethodService() {

    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var symbols = false          // false = letters page, true = .?123 page
    private var small = false            // false = big mode, true = small (compact) mode
    private val keyViews = mutableListOf<KeyView>()
    private val handler = Handler(Looper.getMainLooper())
    private var pal = Palette(false)
    private var rootView: View? = null

    // Theme and size are chosen inside the app (MainActivity)
    private val prefs by lazy { getSharedPreferences("kb", Context.MODE_PRIVATE) }

    private fun systemIsDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun wantDark(): Boolean = when (prefs.getString("theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> systemIsDark()
    }

    private fun wantSmall(): Boolean = prefs.getString("mode", "big") == "small"

    private fun rebuild() {
        setInputView(onCreateInputView())
    }

    // ---------- Return/Go key info ----------
    private fun actionId(): Int = (currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
    private fun hasAction(): Boolean {
        val noEnter = ((currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val a = actionId()
        return !noEnter && a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED
    }
    private fun goLabel(): String = if (!hasAction()) "return" else when (actionId()) {
        EditorInfo.IME_ACTION_GO -> "go"
        EditorInfo.IME_ACTION_SEARCH -> "search"
        EditorInfo.IME_ACTION_SEND -> "send"
        EditorInfo.IME_ACTION_DONE -> "done"
        EditorInfo.IME_ACTION_NEXT -> "next"
        EditorInfo.IME_ACTION_PREVIOUS -> "previous"
        else -> "return"
    }

    // =====================  BIG MODE layouts  =====================
    private val letterRows: List<List<K>> = listOf(
        listOf(
            K("`", "~"), K("1", "!"), K("2", "@"), K("3", "#"), K("4", "$"), K("5", "%"),
            K("6", "^"), K("7", "&"), K("8", "*"), K("9", "("), K("0", ")"),
            K("-", "_"), K("=", "+"),
            K("delete", weight = 1.6f, type = Type.DELETE, align = Align.RIGHT)
        ),
        listOf(K("tab", weight = 1.6f, type = Type.TAB, align = Align.LEFT)) +
            letters("qwertyuiop") +
            listOf(K("[", "{"), K("]", "}"), K("\\", "|")),
        listOf(K("caps lock", weight = 1.85f, type = Type.CAPS, align = Align.LEFT)) +
            letters("asdfghjkl") +
            listOf(K(";", ":"), K("'", "\""),
                K("go", weight = 1.85f, type = Type.GO, align = Align.RIGHT)),
        listOf(K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.LEFT)) +
            letters("zxcvbnm") +
            listOf(K(",", "<"), K(".", ">"), K("/", "?"),
                K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.RIGHT)),
        bottomRow(".?123")
    )

    private val symbolRows: List<List<K>> = listOf(
        listOf(
            K("`", "~"), K("1", "!"), K("2", "@"), K("3", "#"), K("4", "$"), K("5", "%"),
            K("6", "^"), K("7", "&"), K("8", "*"), K("9", "("), K("0", ")"),
            K("-", "_"), K("=", "+"),
            K("delete", weight = 1.6f, type = Type.DELETE, align = Align.RIGHT)
        ),
        listOf(K("tab", weight = 1.6f, type = Type.TAB, align = Align.LEFT)) +
            plain("€£¥¢©®™°•…") +
            listOf(K("¡"), K("¿"), K("±")),
        listOf(K("", weight = 1.85f, type = Type.INERT)) +
            plain("()[]{}<>|") +
            listOf(K("\""), K("'"),
                K("go", weight = 1.85f, type = Type.GO, align = Align.RIGHT)),
        listOf(K("←", weight = 2.4f, type = Type.LEFT)) +
            plain("@#$%&*§") +
            listOf(K(",", "<"), K(".", ">"), K("/", "?"),
                K("→", weight = 2.4f, type = Type.RIGHT)),
        bottomRow("ABC")
    )

    private fun bottomRow(switchLabel: String) = listOf(
        K("", weight = 1.5f, type = Type.EMOJI, align = Align.LEFT),
        K(switchLabel, weight = 1.5f, type = Type.SYMBOLS, align = Align.LEFT),
        K("", weight = 1.5f, type = Type.MIC, align = Align.LEFT),
        K(" ", weight = 7f, type = Type.SPACE),
        K(".com", weight = 1f, type = Type.DOTCOM),
        K(switchLabel, weight = 1.5f, type = Type.SYMBOLS, align = Align.RIGHT),
        K("", weight = 1.5f, type = Type.HIDE, align = Align.RIGHT)
    )

    // =====================  SMALL MODE layouts  =====================
    private val smallLetterRows: List<List<K>> = listOf(
        hinted("qwertyuiop", "1234567890") + K("", weight = 1f, type = Type.DELETE),
        listOf(K("", weight = 0.5f, type = Type.SPACER)) +
            hinted("asdfghjkl", "@#$&*()'\"") +
            listOf(K("return", weight = 1.5f, type = Type.GO)),
        listOf(K("", weight = 1f, type = Type.SHIFT)) +
            hinted("zxcvbnm", "%-+=/;:") +
            listOf(K(",", "!"), K(".", "?"), K("", weight = 1f, type = Type.SHIFT)),
        smallBottom(".?123")
    )

    private val smallSymbolRows: List<List<K>> = listOf(
        plain("1234567890") + K("", weight = 1f, type = Type.DELETE),
        listOf(K("", weight = 0.5f, type = Type.SPACER)) +
            plain("-/:;()$&@") +
            listOf(K("return", weight = 1.5f, type = Type.GO)),
        listOf(K("←", weight = 1f, type = Type.LEFT)) +
            plain(".,?!'\"#") +
            listOf(K("+"), K("="), K("→", weight = 1f, type = Type.RIGHT)),
        smallBottom("ABC")
    )

    private fun smallBottom(switchLabel: String) = listOf(
        K(switchLabel, weight = 1f, type = Type.SYMBOLS),
        K("", weight = 1f, type = Type.EMOJI),          // globe: switch keyboard
        K("", weight = 1f, type = Type.MIC),
        K(" ", weight = 5.4f, type = Type.SPACE),
        K(switchLabel, weight = 1.3f, type = Type.SYMBOLS),
        K("", weight = 1.3f, type = Type.HIDE)
    )

    override fun onCreateInputView(): View {
        keyViews.clear()
        pal = Palette(wantDark())
        small = wantSmall()

        val dm = resources.displayMetrics
        val dp = dm.density
        val screenW = dm.widthPixels.toFloat()

        val rowH: Int
        val toolbarH: Int
        val gap: Int
        if (small) {
            rowH = maxOf(screenW * 0.080f, 52 * dp).toInt()
            toolbarH = maxOf(screenW * 0.049f, 42 * dp).toInt()
            gap = maxOf(screenW * 0.0066f, 3 * dp).toInt()
        } else {
            rowH = maxOf(screenW * 0.0646f, 48 * dp).toInt()
            toolbarH = maxOf(screenW * 0.040f, 40 * dp).toInt()
            gap = maxOf(screenW * 0.0034f, 2 * dp).toInt()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }

        // ----- Toolbar -----
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(pal.toolbar)
            setPadding(gap * 3, 0, 0, 0)
        }
        fun tool(icon: Icon, tap: () -> Unit) = IconView(this, icon, pal.text, pal.toolbar, tap)
        val toolW = (toolbarH * 1.3f).toInt()
        if (small) {
            toolbar.addView(tool(Icon.UNDO) { sendCtrl(KeyEvent.KEYCODE_Z, false) }, LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.REDO) { sendCtrl(KeyEvent.KEYCODE_Z, true) }, LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.PASTE) { currentInputConnection?.performContextMenuAction(android.R.id.paste) },
                LinearLayout.LayoutParams(toolW, -1))
        } else {
            toolbar.addView(tool(Icon.SCISSORS) { currentInputConnection?.performContextMenuAction(android.R.id.cut) },
                LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.COPY) { currentInputConnection?.performContextMenuAction(android.R.id.copy) },
                LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.PASTE) { currentInputConnection?.performContextMenuAction(android.R.id.paste) },
                LinearLayout.LayoutParams(toolW, -1))
        }
        root.addView(toolbar, LinearLayout.LayoutParams(-1, toolbarH))

        // ----- Key rows -----
        val keysContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(gap, gap, gap, gap)
        }
        val pageRows = when {
            small && symbols -> smallSymbolRows
            small -> smallLetterRows
            symbols -> symbolRows
            else -> letterRows
        }
        for (row in pageRows) {
            val rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in row) {
                val v = KeyView(this, k) { onKey(k) }
                keyViews.add(v)
                rowLayout.addView(
                    v,
                    LinearLayout.LayoutParams(0, -1, k.weight).apply { setMargins(gap, gap, gap, gap) }
                )
            }
            keysContainer.addView(rowLayout, LinearLayout.LayoutParams(-1, rowH))
        }
        root.addView(keysContainer, LinearLayout.LayoutParams(-1, -2))
        rootView = root
        refreshLabels()
        return root
    }

    // ---------- Smooth ease-out when the keyboard opens ----------
    private fun animateIn(v: View) {
        v.animate().cancel()
        val dist = if (v.height > 0) v.height.toFloat() else resources.displayMetrics.heightPixels * 0.35f
        v.translationY = dist
        v.alpha = 0f
        v.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(520)
            .setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f))   // ease-out (fast start, long gentle stop)
            .start()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        rootView?.let { animateIn(it) }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false; caps = false
        // New text field: back to letters, and pick up any change made in the app
        if (symbols || wantDark() != pal.dark || wantSmall() != small) { symbols = false; rebuild() }
        refreshLabels()
    }

    // ---------- Key handling ----------
    private fun sendKey(code: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun sendCtrl(code: Int, withShift: Boolean) {
        val ic = currentInputConnection ?: return
        var meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (withShift) meta = meta or KeyEvent.META_SHIFT_ON
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }

    /** Text chosen from the long-press bubble or a flick-down. */
    fun commitAlt(text: String) {
        currentInputConnection?.commitText(text, 1)
        if (shift && !caps) { shift = false; refreshLabels() }
    }

    private fun onKey(k: K) {
        val ic = currentInputConnection ?: return
        when (k.type) {
            Type.CHAR -> {
                val out = when {
                    k.base[0].isLetter() -> if (shift || caps) k.base.uppercase() else k.base
                    else -> if (shift && k.top != null && !small) k.top else k.base
                }
                ic.commitText(out, 1)
                if (shift && !caps) { shift = false; refreshLabels() }
            }
            Type.SPACE -> ic.commitText(" ", 1)
            Type.DOTCOM -> ic.commitText(".com", 1)
            Type.TAB -> ic.commitText("\t", 1)
            Type.DELETE -> deleteOnce()
            Type.SHIFT -> {
                // tap = one capital, double-tap = caps lock, tap again = off
                val now = SystemClock.uptimeMillis()
                if (caps) { caps = false; shift = false }
                else if (shift && now - lastShiftTap < 400) { caps = true }
                else { shift = !shift }
                lastShiftTap = now
                refreshLabels()
            }
            Type.CAPS -> { caps = !caps; refreshLabels() }
            Type.LEFT -> sendKey(KeyEvent.KEYCODE_DPAD_LEFT)
            Type.RIGHT -> sendKey(KeyEvent.KEYCODE_DPAD_RIGHT)
            Type.GO -> {
                if (hasAction()) ic.performEditorAction(actionId()) else sendKey(KeyEvent.KEYCODE_ENTER)
            }
            Type.SYMBOLS -> {
                symbols = !symbols
                handler.post { rebuild() }
            }
            Type.HIDE -> requestHideSelf(0)
            Type.EMOJI -> {
                if (small) {
                    // globe key: switch to the next keyboard
                    @Suppress("DEPRECATION")
                    if (!switchToNextInputMethod(false)) {
                        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                    }
                }
                // TODO: emoji picker for big mode
            }
            Type.MIC, Type.INERT, Type.SPACER -> { /* TODO: voice input */ }
        }
    }

    private fun deleteOnce() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel.isNullOrEmpty()) ic.deleteSurroundingText(1, 0) else ic.commitText("", 1)
    }

    private var repeater: Runnable? = null

    fun startRepeatDelete() {
        deleteOnce()
        val r = object : Runnable {
            override fun run() { deleteOnce(); handler.postDelayed(this, 50) }
        }
        repeater = r
        handler.postDelayed(r, 400)
    }

    fun stopRepeatDelete() { repeater?.let { handler.removeCallbacks(it) }; repeater = null }

    private fun refreshLabels() {
        keyViews.forEach {
            it.shifted = shift || caps
            it.capsOn = caps
            it.active = (it.key.type == Type.CAPS && caps) || (it.key.type == Type.SHIFT && (shift || caps))
            it.invalidate()
        }
    }

    // ---------- Custom key view ----------
    inner class KeyView(ctx: Context, val key: K, private val onClick: () -> Unit) : View(ctx) {
        var shifted = false
        var capsOn = false
        var active = false
        private var down = false
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
        private val isDark = key.type !in listOf(Type.CHAR, Type.SPACE, Type.DOTCOM)

        // long-press bubble
        private val alts: List<String> = if (key.type == Type.CHAR) ALTERNATES[key.base] ?: emptyList() else emptyList()
        private var popup: PopupWindow? = null
        private var altView: AltView? = null
        private var popupLeft = 0
        private val longRun = Runnable { showAlts() }

        // flick down (small mode): types the tiny hint symbol
        private val flickText: String? =
            if (key.type == Type.CHAR && small) (key.hint ?: key.top) else null
        private var downY = 0f
        private var flicking = false

        private fun showAlts() {
            if (alts.isEmpty() || flicking) return
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val opts = alts.map {
                if (shifted) { val up = it.uppercase(); if (up.length == 1) up else it } else it
            }
            val cellW = height * 0.95f
            val cellH = height.toFloat()
            val av = AltView(context, opts, cellW, cellH, pal)
            val popW = (cellW * opts.size + 2 * av.pad).toInt()
            val popH = (cellH + 2 * av.pad).toInt()
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            val screenW = resources.displayMetrics.widthPixels
            val x = (loc[0] + width / 2 - popW / 2).coerceIn(0, maxOf(0, screenW - popW))
            val y = loc[1] - popH - (height * 0.1f).toInt()
            val pw = PopupWindow(av, popW, popH, false)
            pw.isTouchable = false
            pw.isClippingEnabled = false
            pw.showAtLocation(this, Gravity.NO_GRAVITY, x, y)
            popup = pw; altView = av; popupLeft = x
        }

        private fun dismissPopup() {
            handler.removeCallbacks(longRun)
            popup?.dismiss()
            popup = null; altView = null
        }

        override fun onDraw(c: Canvas) {
            if (key.type == Type.SPACER) return
            val w = width.toFloat()
            val h = height.toFloat()
            val r = if (small) h * 0.14f else h * 0.08f
            val lip = h * 0.012f

            shadow.color = pal.shadow
            c.drawRoundRect(0f, lip, w, h, r, r, shadow)

            val goBlue = key.type == Type.GO && (!small || hasAction())
            val face = when {
                down -> pal.pressed
                goBlue -> KEY_GO
                active -> pal.keyLight
                isDark -> pal.keyDark
                else -> pal.keyLight
            }
            bg.color = face
            c.drawRoundRect(0f, 0f, w, h - lip, r, r, bg)

            txt.color = pal.text
            when {
                key.type == Type.CHAR && key.top != null -> {
                    txt.textSize = h * 0.27f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.top, w / 2, h * 0.38f, txt)
                    c.drawText(key.base, w / 2, h * 0.80f, txt)
                }
                key.type == Type.CHAR -> {
                    txt.textSize = h * 0.42f; txt.textAlign = Paint.Align.CENTER
                    val s = if (shifted && key.base[0].isLetter()) key.base.uppercase() else key.base
                    c.drawText(s, w / 2, h / 2 - (txt.ascent() + txt.descent()) / 2, txt)
                    if (small && key.hint != null) {
                        // tiny symbol on top (flick down to type it)
                        txt.textSize = h * 0.16f
                        txt.color = (pal.text and 0x00FFFFFF) or (140 shl 24)
                        c.drawText(key.hint, w / 2, h * 0.30f, txt)
                    }
                }
                key.type == Type.SPACE || key.type == Type.INERT -> {}
                key.type == Type.LEFT || key.type == Type.RIGHT -> {
                    txt.textSize = h * 0.45f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.base, w / 2, h / 2 - (txt.ascent() + txt.descent()) / 2, txt)
                }
                key.type == Type.DOTCOM -> {
                    txt.textSize = h * 0.22f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.base, w / 2, h / 2 - (txt.ascent() + txt.descent()) / 2 - h * 0.04f, txt)
                }
                key.type == Type.SHIFT && small ->
                    drawIcon(c, Icon.SHIFT, w / 2, h / 2, h * 0.42f, pal.text, face, on = active, bar = capsOn)
                key.type == Type.DELETE && small ->
                    drawIcon(c, Icon.BACKSPACE, w / 2, h / 2, h * 0.46f, pal.text, face)
                key.type == Type.EMOJI ->
                    if (small) drawIcon(c, Icon.GLOBE, w / 2, h / 2, h * 0.40f, pal.text, face)
                    else drawIcon(c, Icon.SMILEY, h * 0.38f, h * 0.68f, h * 0.36f, pal.text, face)
                key.type == Type.MIC ->
                    if (small) drawIcon(c, Icon.MIC, w / 2, h / 2, h * 0.42f, pal.text, face)
                    else drawIcon(c, Icon.MIC, h * 0.38f, h * 0.68f, h * 0.36f, pal.text, face)
                key.type == Type.HIDE ->
                    if (small) drawIcon(c, Icon.KEYBOARD, w / 2, h / 2, h * 0.46f, pal.text, face)
                    else drawIcon(c, Icon.KEYBOARD, w - h * 0.38f, h * 0.64f, h * 0.40f, pal.text, face)
                else -> {
                    val label = if (key.type == Type.GO && small) goLabel() else key.base
                    txt.textSize = h * (if (small) 0.24f else 0.21f)
                    txt.color = if (goBlue) Color.WHITE else pal.text
                    val m = h * 0.15f
                    val y = if (key.align == Align.CENTER) h / 2 - (txt.ascent() + txt.descent()) / 2 else h - h * 0.15f
                    when (key.align) {
                        Align.LEFT -> { txt.textAlign = Paint.Align.LEFT; c.drawText(label, m, y, txt) }
                        Align.RIGHT -> { txt.textAlign = Paint.Align.RIGHT; c.drawText(label, w - m, y, txt) }
                        else -> { txt.textAlign = Paint.Align.CENTER; c.drawText(label, w / 2, y, txt) }
                    }
                }
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (key.type == Type.SPACER) return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    down = true; invalidate()
                    downY = e.rawY; flicking = false
                    if (key.type == Type.DELETE) startRepeatDelete()
                    if (alts.isNotEmpty()) handler.postDelayed(longRun, 380)
                }
                MotionEvent.ACTION_MOVE -> {
                    val av = altView
                    if (av != null) {
                        val idx = ((e.rawX - popupLeft - av.pad) / av.cellW).toInt().coerceIn(0, av.opts.size - 1)
                        if (idx != av.selected) { av.selected = idx; av.invalidate() }
                    } else if (flickText != null) {
                        flicking = (e.rawY - downY) > height * 0.5f
                        if (flicking) handler.removeCallbacks(longRun)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    down = false; invalidate()
                    handler.removeCallbacks(longRun)
                    val av = altView
                    if (av != null) {
                        commitAlt(av.opts[av.selected])
                        dismissPopup()
                    } else if (flicking && flickText != null) {
                        commitAlt(flickText)
                    } else if (key.type == Type.DELETE) {
                        stopRepeatDelete()
                    } else {
                        onClick()
                    }
                    flicking = false
                }
                MotionEvent.ACTION_CANCEL -> {
                    down = false; invalidate()
                    dismissPopup()
                    flicking = false
                    if (key.type == Type.DELETE) stopRepeatDelete()
                }
            }
            return true
        }
    }
}
