package com.example.tabletkeyboard

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

/** Setup screen: enable the keyboard, pick it, choose size + theme, and test it. */
class MainActivity : Activity() {

    private fun LinearLayout.addChoices(
        prefs: SharedPreferences, title: String, key: String, default: String,
        options: List<Pair<String, String>>
    ) {
        val dp = resources.displayMetrics.density
        addView(TextView(context).apply {
            text = title
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(0, (16 * dp).toInt(), 0, 0)
        })
        val group = RadioGroup(context).apply { orientation = RadioGroup.VERTICAL }
        val ids = HashMap<Int, String>()
        val current = prefs.getString(key, default)
        for ((value, label) in options) {
            val rb = RadioButton(context).apply {
                id = View.generateViewId()
                text = label
                textSize = 16f
                setTextColor(Color.BLACK)
            }
            ids[rb.id] = value
            group.addView(rb)
            if (value == current) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            ids[checkedId]?.let { prefs.edit().putString(key, it).apply() }
        }
        addView(group)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (24 * dp).toInt()
        val prefs = getSharedPreferences("kb", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "Tablet Keyboard"
            textSize = 28f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "1) Enable the keyboard\n2) Choose it as your input method\n3) Pick size and theme\n4) Tap the box at the bottom to test"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad / 2, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Choose keyboard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        root.addChoices(prefs, "3a. Keyboard size", "mode", "big", listOf(
            "big" to "Big mode (full layout)",
            "small" to "Small mode (compact)"
        ))
        root.addChoices(prefs, "3b. Keyboard theme", "theme", "auto", listOf(
            "auto" to "Auto (follow system)",
            "light" to "Light",
            "dark" to "Dark"
        ))

        root.addView(EditText(this).apply {
            hint = "4. Tap here to test"
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = pad })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
    }
}
