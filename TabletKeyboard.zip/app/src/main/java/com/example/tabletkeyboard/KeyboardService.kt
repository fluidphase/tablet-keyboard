package com.example.tabletkeyboard

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

private val KEY_GO = Color.parseColor("#0A84FF")

enum class Type { CHAR, DELETE, TAB, CAPS, SHIFT, GO, SPACE, SYMBOLS, EMOJI, MIC, HIDE, DOTCOM, LEFT, RIGHT, INERT, SPACER, GLOBE }
enum class Align { CENTER, LEFT, RIGHT }
enum class Icon { SMILEY, MIC, KEYBOARD, SCISSORS, COPY, PASTE, SHIFT, BACKSPACE, GLOBE, UNDO, REDO }

data class K(
    val base: String,
    val top: String? = null,       // shifted symbol shown above the base (two-line keys)
    val weight: Float = 1f,
    val type: Type = Type.CHAR,
    val align: Align = Align.CENTER,
    val hint: String? = null       // small mode: tiny symbol on top, typed by flicking down
)

private fun letters(s: String) = s.map { K(it.toString()) }
private fun plain(s: String) = s.map { K(it.toString()) }
private fun plainW(s: String, w: Float) = s.map { K(it.toString(), weight = w) }
private fun hinted(chars: String, hints: String, w: Float = 1f) =
    chars.indices.map { K(chars[it].toString(), weight = w, hint = hints[it].toString()) }
private fun withAlpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a shl 24)
private fun blend(a: Int, b: Int, t: Float): Int {
    val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
    val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
    val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    return Color.rgb(r, g, bl)
}
private fun em(s: String) = s.trim().split(" ").filter { it.isNotEmpty() }

private data class Correction(val original: String, val replacement: String, val sepText: String)

// Characters that finish a word (autocorrect runs when one of these is typed)
private val SEPARATORS = setOf(' ', '.', ',', '!', '?', ';', ':', ')')

// ---------- Long-press alternates ----------
private val ALTERNATES: Map<String, List<String>> = mapOf(
    "a" to listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā"),
    "e" to listOf("è", "é", "ê", "ë", "ē", "ė", "ę"),
    "i" to listOf("î", "ï", "í", "ī", "į", "ì"),
    "o" to listOf("ô", "ö", "ò", "ó", "œ", "ø", "ō", "õ"),
    "u" to listOf("û", "ü", "ù", "ú", "ū"),
    "y" to listOf("ÿ", "ý"),
    "c" to listOf("ç", "ć", "č"),
    "n" to listOf("ñ", "ń"),
    "s" to listOf("ś", "š", "ß"),
    "z" to listOf("ž", "ź", "ż"),
    "l" to listOf("ł"),
    "$" to listOf("€", "£", "¥", "¢"),
    "-" to listOf("–", "—", "•"),
    "." to listOf("…", "·"),
    "?" to listOf("¿"),
    "!" to listOf("¡"),
    "'" to listOf("‘", "’"),
    "\"" to listOf("“", "”", "«", "»"),
    "&" to listOf("§"),
    "=" to listOf("≠", "≈"),
    "0" to listOf("°"),
    "/" to listOf("\\")
)

// ---------- Emoji categories (first tab = recents, filled in at runtime) ----------
private val SMILEYS = "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾"
private val GESTURES = "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤏 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦵 🦶 👂 👃 🧠 👀 👁️ 👅 👄 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙋 🙆 🙅 🤷 🤦 💁 🙇 💃 🕺 🚶 🏃 👯 🧘 🛀"
private val ANIMALS = "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦛 🦏 🐪 🦒 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🕊️ 🐇 🐁 🐀 🐿️ 🌵 🎄 🌲 🌳 🌴 🌱 🌿 ☘️ 🍀 🍁 🍂 🍃 🌸 🌼 🌻 🌹 🌷 🌺 🌞 🌝 🌚"
private val FOOD = "🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥬 🥒 🌶️ 🌽 🥕 🧄 🧅 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 🥞 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🥛 ☕ 🍵 🧃 🥤 🍺 🍻 🥂 🍷 🍸 🍹"
private val ACTIVITY = "⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🎱 🏓 🏸 🥅 🏒 🏏 ⛳ 🏹 🎣 🥊 🥋 🎽 ⛸️ 🛹 🛷 ⛷️ 🏂 🏋️ 🤸 🤺 🏆 🥇 🥈 🥉 🏅 🎖️ 🎮 🕹️ 🎲 🧩 ♟️ 🎯 🎳 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🎬 🎨 🎭 🎪 🎟️ 🎫"
private val TRAVEL = "🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🏍️ 🚲 🛴 🚨 🚔 🚍 🚘 🚖 🚡 🚠 🚟 🚃 🚋 🚞 🚝 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🚀 🛸 🚁 ⛵ 🚤 🛥️ 🚢 ⚓ 🏠 🏡 🏢 🏫 🏥 🏦 🏨 🏪 🏰 🗼 🗽 ⛪ 🕌 🌍 🌎 🌏 🗺️ 🏔️ ⛰️ 🌋 🏖️ 🏝️ 🌅 🌄 🌆 🌃 🌉 🌈 ☀️ 🌤️ ⛅ ☁️ 🌧️ ⛈️ ❄️ ☃️ ⛄ 🌙"
private val OBJECTS = "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 🖱️ 💾 💿 📷 📹 🎥 📞 ☎️ 📺 📻 ⏰ ⌛ 🔋 🔌 💡 🔦 🕯️ 💰 💵 💳 💎 🔧 🔨 ⚙️ 🔫 💣 🔪 🛡️ 🔮 💊 💉 🔑 🗝️ 🚪 🛏️ 🛒 🎁 🎈 🎉 🎊 📦 ✉️ 📧 📝 📁 📅 📌 📎 ✂️ 🔒 🔓 🔍 📖 📚 🏷️"
private val SYMBOLS_E = "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ✨ ⭐ 🌟 💫 ⚡ 🔥 💥 💢 💦 💨 💤 ✅ ❌ ❓ ❗ ‼️ ⁉️ 💯 🔔 🎵 🎶 ➕ ➖ ✔️ ☑️ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔺 🔻 ♻️ ⚠️ 🚫 ⭕ ➡️ ⬅️ ⬆️ ⬇️ 🔄 🔙"

// ---------- Light / dark palettes (with optional see-through) ----------
class Palette(val dark: Boolean, transparencyPct: Int = 0) {
    /** 255 = solid, lower = more see-through */
    val keyAlpha = 255 * (100 - transparencyPct.coerceIn(0, 90)) / 100
    val text = if (dark) Color.WHITE else Color.BLACK
    val toolbarSolid = if (dark) Color.parseColor("#2A2A2D") else Color.parseColor("#DCDDE2")
    val bg = withAlpha(if (dark) Color.parseColor("#1E1E21") else Color.parseColor("#D1D3D9"), keyAlpha)
    val toolbar = withAlpha(toolbarSolid, keyAlpha)
    val keyLight = if (dark) Color.parseColor("#6B6B70") else Color.WHITE
    val keyDark = if (dark) Color.parseColor("#47474B") else Color.parseColor("#B9BDC8")
    val pressed = if (dark) Color.parseColor("#8E8E93") else Color.parseColor("#9EA3B0")
    val shadow = if (dark) Color.BLACK else Color.parseColor("#898A8D")
}

// ---------- Icons drawn with Canvas ----------
private fun drawUndoShape(c: Canvas, cx: Float, cy: Float, r: Float, stroke: Paint) {
    val head = Path()
    head.moveTo(cx - r * 0.35f, cy - r * 0.75f)
    head.lineTo(cx - r * 0.8f, cy - r * 0.3f)
    head.lineTo(cx - r * 0.35f, cy + r * 0.15f)
    c.drawPath(head, stroke)
    val body = Path()
    body.moveTo(cx - r * 0.8f, cy - r * 0.3f)
    body.lineTo(cx + r * 0.2f, cy - r * 0.3f)
    body.cubicTo(cx + r * 0.9f, cy - r * 0.3f, cx + r * 0.9f, cy + r * 0.8f, cx + r * 0.2f, cy + r * 0.8f)
    body.lineTo(cx - r * 0.3f, cy + r * 0.8f)
    c.drawPath(body, stroke)
}

fun drawIcon(c: Canvas, icon: Icon, cx: Float, cy: Float, size: Float,
             color: Int, inner: Int, on: Boolean = false, bar: Boolean = false) {
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; this.color = color
        strokeWidth = size * 0.075f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = color }
    val innerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; this.color = inner }
    val r = size / 2f
    when (icon) {
        Icon.SMILEY -> {
            c.drawCircle(cx, cy, r * 0.9f, stroke)
            c.drawCircle(cx - r * 0.32f, cy - r * 0.2f, r * 0.09f, fill)
            c.drawCircle(cx + r * 0.32f, cy - r * 0.2f, r * 0.09f, fill)
            c.drawArc(RectF(cx - r * 0.5f, cy - r * 0.35f, cx + r * 0.5f, cy + r * 0.55f), 20f, 140f, false, stroke)
        }
        Icon.MIC -> {
            c.drawRoundRect(RectF(cx - r * 0.28f, cy - r * 0.95f, cx + r * 0.28f, cy + r * 0.2f), r * 0.28f, r * 0.28f, stroke)
            c.drawArc(RectF(cx - r * 0.6f, cy - r * 0.45f, cx + r * 0.6f, cy + r * 0.55f), 0f, 180f, false, stroke)
            c.drawLine(cx, cy + r * 0.55f, cx, cy + r * 0.95f, stroke)
        }
        Icon.KEYBOARD -> {
            c.drawRoundRect(RectF(cx - r, cy - r * 0.7f, cx + r, cy + r * 0.2f), r * 0.12f, r * 0.12f, stroke)
            for (i in 0..4) {
                val x = cx - r * 0.65f + i * r * 0.325f
                c.drawCircle(x, cy - r * 0.45f, r * 0.05f, fill)
                c.drawCircle(x, cy - r * 0.2f, r * 0.05f, fill)
            }
            c.drawLine(cx - r * 0.5f, cy, cx + r * 0.5f, cy, stroke)
            val p = Path()
            p.moveTo(cx - r * 0.25f, cy + r * 0.5f); p.lineTo(cx, cy + r * 0.75f); p.lineTo(cx + r * 0.25f, cy + r * 0.5f)
            c.drawPath(p, stroke)
        }
        Icon.SCISSORS -> {
            c.drawCircle(cx - r * 0.55f, cy + r * 0.55f, r * 0.25f, stroke)
            c.drawCircle(cx + r * 0.55f, cy + r * 0.55f, r * 0.25f, stroke)
            c.drawLine(cx - r * 0.4f, cy + r * 0.35f, cx + r * 0.85f, cy - r * 0.8f, stroke)
            c.drawLine(cx + r * 0.4f, cy + r * 0.35f, cx - r * 0.85f, cy - r * 0.8f, stroke)
        }
        Icon.COPY -> {
            c.drawRoundRect(RectF(cx - r * 0.75f, cy - r * 0.85f, cx + r * 0.2f, cy + r * 0.35f), r * 0.12f, r * 0.12f, stroke)
            c.drawRoundRect(RectF(cx - r * 0.2f, cy - r * 0.35f, cx + r * 0.75f, cy + r * 0.85f), r * 0.12f, r * 0.12f, stroke)
        }
        Icon.PASTE -> {
            c.drawRoundRect(RectF(cx - r * 0.7f, cy - r * 0.75f, cx + r * 0.7f, cy + r * 0.95f), r * 0.15f, r * 0.15f, fill)
            c.drawRoundRect(RectF(cx - r * 0.45f, cy - r * 0.4f, cx + r * 0.45f, cy + r * 0.75f), r * 0.08f, r * 0.08f, innerFill)
            c.drawRoundRect(RectF(cx - r * 0.3f, cy - r * 0.95f, cx + r * 0.3f, cy - r * 0.5f), r * 0.1f, r * 0.1f, fill)
        }
        Icon.SHIFT -> {
            val p = Path()
            p.moveTo(cx, cy - r * 0.85f)
            p.lineTo(cx + r * 0.8f, cy)
            p.lineTo(cx + r * 0.4f, cy)
            p.lineTo(cx + r * 0.4f, cy + r * 0.75f)
            p.lineTo(cx - r * 0.4f, cy + r * 0.75f)
            p.lineTo(cx - r * 0.4f, cy)
            p.lineTo(cx - r * 0.8f, cy)
            p.close()
            if (on) c.drawPath(p, fill)
            c.drawPath(p, stroke)
            if (bar) c.drawLine(cx - r * 0.4f, cy + r * 1.0f, cx + r * 0.4f, cy + r * 1.0f, stroke)
        }
        Icon.BACKSPACE -> {
            val p = Path()
            p.moveTo(cx - r * 1.0f, cy)
            p.lineTo(cx - r * 0.55f, cy - r * 0.6f)
            p.lineTo(cx + r * 0.95f, cy - r * 0.6f)
            p.lineTo(cx + r * 0.95f, cy + r * 0.6f)
            p.lineTo(cx - r * 0.55f, cy + r * 0.6f)
            p.close()
            c.drawPath(p, stroke)
            c.drawLine(cx - r * 0.05f, cy - r * 0.25f, cx + r * 0.5f, cy + r * 0.25f, stroke)
            c.drawLine(cx - r * 0.05f, cy + r * 0.25f, cx + r * 0.5f, cy - r * 0.25f, stroke)
        }
        Icon.GLOBE -> {
            c.drawCircle(cx, cy, r * 0.9f, stroke)
            c.drawOval(RectF(cx - r * 0.4f, cy - r * 0.9f, cx + r * 0.4f, cy + r * 0.9f), stroke)
            c.drawLine(cx - r * 0.9f, cy, cx + r * 0.9f, cy, stroke)
            c.drawLine(cx - r * 0.7f, cy - r * 0.45f, cx + r * 0.7f, cy - r * 0.45f, stroke)
            c.drawLine(cx - r * 0.7f, cy + r * 0.45f, cx + r * 0.7f, cy + r * 0.45f, stroke)
        }
        Icon.UNDO -> drawUndoShape(c, cx, cy, r, stroke)
        Icon.REDO -> {
            c.save()
            c.scale(-1f, 1f, cx, cy)
            drawUndoShape(c, cx, cy, r, stroke)
            c.restore()
        }
    }
}

class IconView(
    ctx: Context, private val icon: Icon, private val color: Int, private val inner: Int,
    private val onTap: () -> Unit
) : View(ctx) {
    init { setOnClickListener { onTap() } }
    override fun onDraw(c: Canvas) {
        drawIcon(c, icon, width / 2f, height / 2f, minOf(width, height) * 0.6f, color, inner)
    }
}

// ---------- A suggestion slot whose words crossfade when they change ----------
class FadeText(
    ctx: Context,
    private val sizePx: Float,
    private val textCol: Int,
    private val padPx: Int
) : FrameLayout(ctx) {
    private val a: TextView = makeTv(ctx)
    private val b: TextView = makeTv(ctx)
    private var front: TextView = a
    private var shown = ""

    private fun makeTv(c: Context): TextView {
        val t = TextView(c)
        t.gravity = Gravity.CENTER
        t.setSingleLine(true)
        t.ellipsize = TextUtils.TruncateAt.END
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx)
        t.setTextColor(textCol)
        t.setPadding(padPx, 0, padPx, 0)
        return t
    }

    init {
        addView(a, LayoutParams(-1, -1))
        addView(b, LayoutParams(-1, -1))
        b.alpha = 0f
    }

    fun setLabel(t: String) {
        if (t == shown) return
        shown = t
        val back = if (front === a) b else a
        back.text = t
        back.animate().cancel()
        front.animate().cancel()
        back.animate().alpha(if (t.isEmpty()) 0f else 1f).setDuration(130).start()
        front.animate().alpha(0f).setDuration(130).start()
        front = back
    }
}

// ---------- The popup bubble shown on long-press ----------
class AltView(
    ctx: Context, val opts: List<String>,
    val cellW: Float, val cellH: Float, private val pal: Palette
) : View(ctx) {
    var selected = 0
    val pad = cellH * 0.08f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rad = cellH * 0.18f
        p.style = Paint.Style.FILL; p.color = pal.keyLight
        c.drawRoundRect(0f, 0f, w, h, rad, rad, p)
        p.style = Paint.Style.STROKE; p.color = pal.shadow; p.strokeWidth = 2f
        c.drawRoundRect(1f, 1f, w - 1f, h - 1f, rad, rad, p)
        for (i in opts.indices) {
            val left = pad + i * cellW
            if (i == selected) {
                p.style = Paint.Style.FILL; p.color = KEY_GO
                c.drawRoundRect(left, pad, left + cellW, pad + cellH, cellH * 0.14f, cellH * 0.14f, p)
            }
            p.style = Paint.Style.FILL
            p.color = if (i == selected) Color.WHITE else pal.text
            p.textSize = cellH * 0.5f
            p.textAlign = Paint.Align.CENTER
            c.drawText(opts[i], left + cellW / 2, pad + cellH / 2 - (p.ascent() + p.descent()) / 2, p)
        }
    }
}

class KeyboardService : InputMethodService() {

    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var symbols = false          // false = letters page, true = .?123 page
    private var small = false            // false = big mode, true = small (compact) mode
    private var emojiOpen = false
    private var emojiCat = 1
    private val keyViews = mutableListOf<KeyView>()
    private val handler = Handler(Looper.getMainLooper())
    private var pal = Palette(false)
    private var rootView: View? = null
    private var builtKey = ""

    // Settings are chosen inside the app (MainActivity)
    private val prefs by lazy { getSharedPreferences("kb", Context.MODE_PRIVATE) }

    private fun systemIsDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun wantDark(): Boolean = when (prefs.getString("theme", "auto")) {
        "dark" -> true
        "light" -> false
        else -> systemIsDark()
    }

    private fun wantSmall(): Boolean = prefs.getString("mode", "big") == "small"
    private fun numRow(): Boolean =
        if (small) prefs.getBoolean("numrow_small", false) else prefs.getBoolean("numrow_big", true)
    private fun showSug(): Boolean = prefs.getBoolean("suggest", true)
    private fun showIcons(): Boolean = prefs.getBoolean("toolbar_icons", false) || !showSug()
    private fun autocorrectOn(): Boolean = prefs.getBoolean("autocorrect", true)
    private fun transparency(): Int = prefs.getInt("transparency", 0)

    private fun layoutKey(): String =
        "${wantDark()}|${wantSmall()}|${prefs.getBoolean("numrow_big", true)}|" +
            "${prefs.getBoolean("numrow_small", false)}|${showSug()}|${showIcons()}|${transparency()}"

    private fun rebuild() {
        setInputView(onCreateInputView())
    }

    /** Needed so the see-through setting can actually show the app behind the keyboard. */
    private fun makeWindowTransparent() {
        try { window?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)) } catch (_: Throwable) { }
    }

    // ---------- Return/Go key info ----------
    private fun actionId(): Int = (currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
    private fun hasAction(): Boolean {
        val noEnter = ((currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val a = actionId()
        return !noEnter && a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED
    }
    private fun goLabel(): String = if (!hasAction()) "return" else when (actionId()) {
        EditorInfo.IME_ACTION_GO -> "go"
        EditorInfo.IME_ACTION_SEARCH -> "search"
        EditorInfo.IME_ACTION_SEND -> "send"
        EditorInfo.IME_ACTION_DONE -> "done"
        EditorInfo.IME_ACTION_NEXT -> "next"
        EditorInfo.IME_ACTION_PREVIOUS -> "previous"
        else -> "return"
    }

    // =====================  BIG MODE layouts  =====================
    private val letterRows: List<List<K>> = listOf(
        listOf(
            K("`", "~"), K("1", "!"), K("2", "@"), K("3", "#"), K("4", "$"), K("5", "%"),
            K("6", "^"), K("7", "&"), K("8", "*"), K("9", "("), K("0", ")"),
            K("-", "_"), K("=", "+"),
            K("delete", weight = 1.6f, type = Type.DELETE, align = Align.RIGHT)
        ),
        listOf(K("tab", weight = 1.6f, type = Type.TAB, align = Align.LEFT)) +
            letters("qwertyuiop") +
            listOf(K("[", "{"), K("]", "}"), K("\\", "|")),
        listOf(K("caps lock", weight = 1.85f, type = Type.CAPS, align = Align.LEFT)) +
            letters("asdfghjkl") +
            listOf(K(";", ":"), K("'", "\""),
                K("go", weight = 1.85f, type = Type.GO, align = Align.RIGHT)),
        listOf(K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.LEFT)) +
            letters("zxcvbnm") +
            listOf(K(",", "<"), K(".", ">"), K("/", "?"),
                K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.RIGHT)),
        bottomRow(".?123")
    )

    // Big letters, number row hidden: delete moves to the end of the Q row
    private val letterRowsNoNum: List<List<K>> = listOf(
        listOf(K("tab", weight = 1.3f, type = Type.TAB, align = Align.LEFT)) +
            letters("qwertyuiop") +
            listOf(K("[", "{"), K("]", "}"),
                K("delete", weight = 1.5f, type = Type.DELETE, align = Align.RIGHT))
    ) + letterRows.subList(2, 5)

    private val symbolRows: List<List<K>> = listOf(
        listOf(
            K("`", "~"), K("1", "!"), K("2", "@"), K("3", "#"), K("4", "$"), K("5", "%"),
            K("6", "^"), K("7", "&"), K("8", "*"), K("9", "("), K("0", ")"),
            K("-", "_"), K("=", "+"),
            K("delete", weight = 1.6f, type = Type.DELETE, align = Align.RIGHT)
        ),
        listOf(K("tab", weight = 1.6f, type = Type.TAB, align = Align.LEFT)) +
            plain("€£¥¢©®™°•…") +
            listOf(K("¡"), K("¿"), K("±")),
        listOf(K("", weight = 1.85f, type = Type.INERT)) +
            plain("()[]{}<>|") +
            listOf(K("\""), K("'"),
                K("go", weight = 1.85f, type = Type.GO, align = Align.RIGHT)),
        listOf(K("←", weight = 2.4f, type = Type.LEFT)) +
            plain("@#$%&*!") +
            listOf(K(","), K("."), K("?"), K("/"),
                K("→", weight = 2.4f, type = Type.RIGHT)),
        bottomRow("ABC")
    )

    // Big symbols page when the number row is hidden: numbers take the top row (4 rows, same height)
    private val symbolRowsNoNum: List<List<K>> = listOf(
        listOf(K("tab", weight = 1.3f, type = Type.TAB, align = Align.LEFT)) +
            plain("1234567890") +
            listOf(K("-"), K("="),
                K("delete", weight = 1.5f, type = Type.DELETE, align = Align.RIGHT))
    ) + symbolRows.subList(2, 5)

    private fun bottomRow(switchLabel: String) = listOf(
        K("", weight = 1.5f, type = Type.EMOJI, align = Align.LEFT),
        K(switchLabel, weight = 1.5f, type = Type.SYMBOLS, align = Align.LEFT),
        K("", weight = 1.5f, type = Type.MIC, align = Align.LEFT),
        K(" ", weight = 7f, type = Type.SPACE),
        K(".com", weight = 1f, type = Type.DOTCOM),
        K(switchLabel, weight = 1.5f, type = Type.SYMBOLS, align = Align.RIGHT),
        K("", weight = 1.5f, type = Type.HIDE, align = Align.RIGHT)
    )

    // =====================  SMALL MODE layouts  =====================
    private fun smallLetters(num: Boolean): List<List<K>> {
        val r2 = listOf(K("", weight = 0.5f, type = Type.SPACER)) +
            hinted("asdfghjkl", "@#$&*()'\"") +
            listOf(K("return", weight = 1.5f, type = Type.GO))
        val r3 = listOf(K("", weight = 1f, type = Type.SHIFT)) +
            hinted("zxcvbnm", "%-+=/;:") +
            listOf(K(",", "!"), K(".", "?"), K("", weight = 1f, type = Type.SHIFT))
        return if (num) {
            listOf(
                hinted("1234567890", "!@#$%^&*()") + K("", weight = 1f, type = Type.DELETE),
                plainW("qwertyuiop", 1.1f),
                r2, r3, smallBottom(".?123")
            )
        } else {
            listOf(
                hinted("qwertyuiop", "1234567890") + K("", weight = 1f, type = Type.DELETE),
                r2, r3, smallBottom(".?123")
            )
        }
    }

    private fun smallSymbols(num: Boolean): List<List<K>> {
        val numbers = plain("1234567890") + K("", weight = 1f, type = Type.DELETE)
        val r2 = listOf(K("", weight = 0.5f, type = Type.SPACER)) +
            plain("-/:;()$&@") +
            listOf(K("return", weight = 1.5f, type = Type.GO))
        val r3 = listOf(K("←", weight = 1f, type = Type.LEFT)) +
            plain(".,?!'\"#") +
            listOf(K("+"), K("="), K("→", weight = 1f, type = Type.RIGHT))
        return if (num) {
            listOf(numbers, plainW("€£¥¢©®™°•…", 1.1f), r2, r3, smallBottom("ABC"))
        } else {
            listOf(numbers, r2, r3, smallBottom("ABC"))
        }
    }

    private fun smallBottom(switchLabel: String) = listOf(
        K(switchLabel, weight = 1f, type = Type.SYMBOLS),
        K("", weight = 1f, type = Type.EMOJI),          // smiley key: opens emoji
        K("", weight = 1f, type = Type.MIC),
        K(" ", weight = 5.4f, type = Type.SPACE),
        K(switchLabel, weight = 1.3f, type = Type.SYMBOLS),
        K("", weight = 1.3f, type = Type.HIDE)
    )

    private fun currentRows(): List<List<K>> {
        val num = numRow()
        return when {
            small && symbols -> smallSymbols(num)
            small -> smallLetters(num)
            symbols -> if (num) symbolRows else symbolRowsNoNum
            else -> if (num) letterRows else letterRowsNoNum
        }
    }

    // =====================  Emoji  =====================
    private val emojiCats: List<Pair<String, List<String>>> by lazy {
        listOf(
            "🕒" to emptyList<String>(),
            "😀" to em(SMILEYS),
            "👍" to em(GESTURES),
            "🐶" to em(ANIMALS),
            "🍎" to em(FOOD),
            "⚽" to em(ACTIVITY),
            "🚗" to em(TRAVEL),
            "💡" to em(OBJECTS),
            "❤️" to em(SYMBOLS_E)
        )
    }

    private fun recentEmoji(): List<String> =
        (prefs.getString("recent_emoji", "") ?: "").split(" ").filter { it.isNotEmpty() }

    private fun addRecent(e: String) {
        val l = ArrayList(recentEmoji())
        l.remove(e)
        l.add(0, e)
        prefs.edit().putString("recent_emoji", l.take(32).joinToString(" ")).apply()
    }

    private fun commitEmoji(e: String) {
        lastCorrection = null
        currentInputConnection?.commitText(e, 1)
        typedBuf.setLength(0)
        addRecent(e)
        afterEdit()
    }

    private fun switchKeyboard() {
        if (!switchToNextInputMethod(false)) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
    }

    private fun buildEmojiPanel(rowH: Int, gap: Int, rowsCount: Int, screenW: Float): View {
        val totalH = rowH * rowsCount
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(gap, gap, gap, gap)
        }

        val cols = maxOf(6, ((screenW - 2 * gap) / (rowH * 0.95f)).toInt())
        val cellW = ((screenW - 2 * gap) / cols).toInt()
        val cellH = (rowH * 0.95f).toInt()

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val catViews = ArrayList<TextView>()
        fun styleCats() {
            for ((i, tv) in catViews.withIndex()) {
                tv.background = if (i == emojiCat) GradientDrawable().apply {
                    setColor((pal.text and 0x00FFFFFF) or (50 shl 24))
                    cornerRadius = rowH * 0.2f
                } else null
            }
        }
        fun fill() {
            content.removeAllViews()
            val list = if (emojiCat == 0) recentEmoji() else emojiCats[emojiCat].second
            if (list.isEmpty()) {
                content.addView(TextView(this).apply {
                    text = "No recent emoji yet"
                    setTextColor(pal.text)
                    gravity = Gravity.CENTER
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, rowH * 0.3f)
                    setPadding(0, rowH / 2, 0, 0)
                }, LinearLayout.LayoutParams(-1, -2))
                return
            }
            var i = 0
            while (i < list.size) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (j in i until minOf(i + cols, list.size)) {
                    val e = list[j]
                    line.addView(TextView(this).apply {
                        text = e
                        gravity = Gravity.CENTER
                        setTextSize(TypedValue.COMPLEX_UNIT_PX, cellH * 0.55f)
                        setOnClickListener { commitEmoji(e) }
                    }, LinearLayout.LayoutParams(cellW, cellH))
                }
                content.addView(line, LinearLayout.LayoutParams(-2, cellH))
                i += cols
            }
        }
        fill()
        panel.addView(scroll, LinearLayout.LayoutParams(-1, totalH - rowH))

        // Bottom bar: ABC | globe | categories | delete
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun lp(w: Float) = LinearLayout.LayoutParams(0, -1, w).apply { setMargins(gap, gap, gap, gap) }
        bar.addView(KeyView(this, K("ABC", weight = 1.3f, type = Type.SYMBOLS)) {
            emojiOpen = false
            handler.post { rebuild() }
        }, lp(1.3f))
        bar.addView(KeyView(this, K("", weight = 1f, type = Type.GLOBE)) { switchKeyboard() }, lp(1f))
        for (i in emojiCats.indices) {
            val tv = TextView(this).apply {
                text = emojiCats[i].first
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_PX, rowH * 0.42f)
                setOnClickListener {
                    emojiCat = i
                    fill()
                    scroll.scrollTo(0, 0)
                    styleCats()
                }
            }
            catViews.add(tv)
            bar.addView(tv, lp(1f))
        }
        bar.addView(KeyView(this, K("", weight = 1.3f, type = Type.DELETE)) { }, lp(1.3f))
        styleCats()
        panel.addView(bar, LinearLayout.LayoutParams(-1, rowH))

        panel.layoutParams = LinearLayout.LayoutParams(-1, totalH + 2 * gap)
        return panel
    }

    // =====================  Build the keyboard view  =====================
    override fun onCreateInputView(): View {
        keyViews.clear()
        pal = Palette(wantDark(), transparency())
        small = wantSmall()
        builtKey = layoutKey()

        val dm = resources.displayMetrics
        val dp = dm.density
        val screenW = dm.widthPixels.toFloat()

        val rowH: Int
        val toolbarH: Int
        val gap: Int
        if (small) {
            rowH = maxOf(screenW * 0.080f, 52 * dp).toInt()
            toolbarH = if (showSug()) maxOf(screenW * 0.058f, 48 * dp).toInt()
                else maxOf(screenW * 0.049f, 42 * dp).toInt()
            gap = maxOf(screenW * 0.0066f, 3 * dp).toInt()
        } else {
            rowH = maxOf(screenW * 0.0646f, 48 * dp).toInt()
            toolbarH = if (showSug()) maxOf(screenW * 0.048f, 44 * dp).toInt()
                else maxOf(screenW * 0.040f, 40 * dp).toInt()
            gap = maxOf(screenW * 0.0034f, 2 * dp).toInt()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }

        // ----- Toolbar: icons + suggestion slots -----
        val iconsOn = showIcons()
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(pal.toolbar)
            if (iconsOn) setPadding(gap * 3, 0, gap * 3, 0)
        }
        fun tool(icon: Icon, tap: () -> Unit) = IconView(this, icon, pal.text, pal.toolbarSolid, tap)
        val toolW = (toolbarH * 1.3f).toInt()
        if (iconsOn && small) {
            toolbar.addView(tool(Icon.UNDO) { sendCtrl(KeyEvent.KEYCODE_Z, false) }, LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.REDO) { sendCtrl(KeyEvent.KEYCODE_Z, true) }, LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.PASTE) { currentInputConnection?.performContextMenuAction(android.R.id.paste) },
                LinearLayout.LayoutParams(toolW, -1))
        } else if (iconsOn) {
            toolbar.addView(tool(Icon.SCISSORS) { currentInputConnection?.performContextMenuAction(android.R.id.cut) },
                LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.COPY) { currentInputConnection?.performContextMenuAction(android.R.id.copy) },
                LinearLayout.LayoutParams(toolW, -1))
            toolbar.addView(tool(Icon.PASTE) { currentInputConnection?.performContextMenuAction(android.R.id.paste) },
                LinearLayout.LayoutParams(toolW, -1))
        }

        if (showSug()) {
            val sugBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val dividerColor = (pal.text and 0x00FFFFFF) or (60 shl 24)
            val tvs = Array(3) { i ->
                FadeText(this, toolbarH * 0.44f, pal.text, gap * 2).apply {
                    setOnClickListener { onSuggestionTap(i) }
                }
            }
            for (i in 0..2) {
                if (i > 0) {
                    sugBox.addView(View(this).apply { setBackgroundColor(dividerColor) },
                        LinearLayout.LayoutParams(maxOf(1, dp.toInt()), -1).apply {
                            setMargins(0, (toolbarH * 0.22f).toInt(), 0, (toolbarH * 0.22f).toInt())
                        })
                }
                sugBox.addView(tvs[i], LinearLayout.LayoutParams(0, -1, 1f))
            }
            toolbar.addView(sugBox, LinearLayout.LayoutParams(0, -1, 1f))
            sugViews = tvs
        } else {
            sugViews = null
        }
        root.addView(toolbar, LinearLayout.LayoutParams(-1, toolbarH))

        // ----- Keys (or the emoji panel) -----
        if (emojiOpen) {
            root.addView(buildEmojiPanel(rowH, gap, currentRows().size, screenW))
        } else {
            val keysContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(gap, gap, gap, gap)
            }
            for (row in currentRows()) {
                val rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (k in row) {
                    val v = KeyView(this, k) { onKey(k) }
                    keyViews.add(v)
                    rowLayout.addView(
                        v,
                        LinearLayout.LayoutParams(0, -1, k.weight).apply { setMargins(gap, gap, gap, gap) }
                    )
                }
                keysContainer.addView(rowLayout, LinearLayout.LayoutParams(-1, rowH))
            }
            root.addView(keysContainer, LinearLayout.LayoutParams(-1, -2))
        }
        rootView = root
        refreshLabels()
        updateBar()
        makeWindowTransparent()
        return root
    }

    // ---------- Smooth ease-out slide when the keyboard opens (no fade) ----------
    private fun animateIn(v: View) {
        v.animate().cancel()
        val dist = if (v.height > 0) v.height.toFloat() else resources.displayMetrics.heightPixels * 0.35f
        v.alpha = 1f
        v.translationY = dist
        v.animate()
            .translationY(0f)
            .setDuration(520)
            .setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f))   // ease-out
            .start()
    }

    private fun hideAnimated() {
        val v = rootView
        if (v == null || v.height == 0) { requestHideSelf(0); return }
        v.animate().cancel()
        v.animate()
            .translationY(v.height.toFloat())
            .setDuration(260)
            .setInterpolator(AccelerateInterpolator(1.6f))
            .withEndAction { requestHideSelf(0) }
            .start()
    }

    override fun onCreate() {
        super.onCreate()
        engine.loadAsync()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        makeWindowTransparent()
        rootView?.let { animateIn(it) }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        rootView?.animate()?.cancel()
        rootView?.translationY = 0f
        rootView?.alpha = 1f
        shift = false; caps = false
        typedBuf.setLength(0)
        lastCorrection = null
        curWord = ""; sugs = emptyList(); isTypo = false; confident = false; lastRequested = ""
        if (symbols || emojiOpen || layoutKey() != builtKey) {
            symbols = false; emojiOpen = false
            rebuild()
        }
        refreshLabels()
        afterEdit()
    }

    override fun onDestroy() {
        exec.shutdownNow()
        super.onDestroy()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        afterEdit()   // cursor moved (e.g. user tapped in the text): refresh suggestions
    }

    // =====================  Suggestions + autocorrect (offline dictionary)  =====================
    private val engine by lazy { SpellEngine(applicationContext) }
    private val exec = Executors.newSingleThreadExecutor()
    private var reqId = 0

    private var sugViews: Array<FadeText>? = null
    private val slotVal = arrayOfNulls<String>(3)
    private val slotKeep = BooleanArray(3)

    private var curWord = ""
    private var sugs: List<String> = emptyList()
    private var isTypo = false
    private var confident = false
    private var pendingWord = ""
    private var lastRequested = ""
    private val typedBuf = StringBuilder()          // fallback if the app hides its text from us
    private var lastCorrection: Correction? = null
    private val ignored: MutableSet<String> by lazy {
        (prefs.getStringSet("ignored", emptySet()) ?: emptySet()).toMutableSet()
    }

    private val requestRun = Runnable {
        val w = pendingWord
        val id = ++reqId
        try {
            exec.execute {
                val r = engine.analyze(w)
                handler.post { if (id == reqId && w == curWord) applyResult(r) }
            }
        } catch (_: Throwable) { }
    }

    private fun applyResult(r: SpellResult) {
        sugs = r.sugs.filter { !it.equals(curWord, true) }.take(3)
        isTypo = r.typo
        confident = r.confident
        updateBar()
    }

    private fun fieldOk(): Boolean {
        val ei = currentInputEditorInfo ?: return false
        val t = ei.inputType
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        if (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_URI ||
            v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) return false
        if ((t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        return true
    }

    /** The word right before the cursor (letters and apostrophes). */
    private fun currentWord(): String {
        val ic = currentInputConnection ?: return ""
        val before = ic.getTextBeforeCursor(32, 0) ?: return typedBuf.toString()
        var i = before.length
        while (i > 0 && (before[i - 1].isLetter() || before[i - 1] == '\'')) i--
        while (i < before.length && before[i] == '\'') i++       // ignore opening quote marks
        return before.subSequence(i, before.length).toString()
    }

    private fun atSentenceStart(word: String): Boolean {
        val ic = currentInputConnection ?: return true
        val before = ic.getTextBeforeCursor(word.length + 40, 0)?.toString() ?: return true
        val head = before.dropLast(word.length).trimEnd(' ', '\t')
        return head.isEmpty() || head.last() in ".!?\n"
    }

    private fun matchCase(orig: String, sug: String): String = when {
        orig.length > 1 && orig.all { it.isUpperCase() } -> sug.uppercase()
        orig.isNotEmpty() && orig[0].isUpperCase() -> sug.replaceFirstChar { it.uppercase() }
        else -> sug
    }

    /** Call after any change to the text. */
    private fun afterEdit() {
        if (!showSug() || !fieldOk()) {
            curWord = ""; sugs = emptyList(); isTypo = false; confident = false
            updateBar()
            return
        }
        val w = currentWord()
        if (w != curWord) { curWord = w; sugs = emptyList(); isTypo = false; confident = false; lastRequested = "" }
        updateBar()
        if (w.isNotEmpty() && w != lastRequested) {
            lastRequested = w
            pendingWord = w
            handler.removeCallbacks(requestRun)
            handler.postDelayed(requestRun, 50)
        }
    }

    private fun updateBar() {
        val tv = sugViews ?: return
        val w = curWord
        val disp = arrayOfNulls<String>(3)
        for (i in 0..2) { slotVal[i] = null; slotKeep[i] = false }
        if (w.isNotEmpty()) {
            if (isTypo && sugs.isNotEmpty()) {
                disp[0] = "\"$w\""; slotVal[0] = w; slotKeep[0] = true
                val a = matchCase(w, sugs[0]); disp[1] = a; slotVal[1] = a
                if (sugs.size > 1) { val b = matchCase(w, sugs[1]); disp[2] = b; slotVal[2] = b }
            } else {
                disp[1] = w; slotVal[1] = w; slotKeep[1] = true
                if (sugs.isNotEmpty()) { val a = matchCase(w, sugs[0]); disp[0] = a; slotVal[0] = a }
                if (sugs.size > 1) { val b = matchCase(w, sugs[1]); disp[2] = b; slotVal[2] = b }
            }
        }
        for (i in 0..2) tv[i].setLabel(disp[i] ?: "")
    }

    private fun onSuggestionTap(i: Int) {
        val v = slotVal[i] ?: return
        val ic = currentInputConnection ?: return
        val w = curWord
        lastCorrection = null
        ic.beginBatchEdit()
        if (slotKeep[i]) {
            if (isTypo) addIgnored(w)         // you chose your own spelling: stop correcting it
            ic.commitText(" ", 1)
        } else {
            ic.deleteSurroundingText(w.length, 0)
            ic.commitText("$v ", 1)
        }
        ic.endBatchEdit()
        typedBuf.setLength(0)
        curWord = ""; sugs = emptyList(); isTypo = false; confident = false; lastRequested = ""
        afterEdit()
    }

    private fun addIgnored(word: String) {
        ignored.add(word.lowercase())
        prefs.edit().putStringSet("ignored", HashSet(ignored)).apply()
    }

    /** Fix the word before the cursor (called just before a space/punctuation is typed). */
    private fun maybeAutocorrect(): Pair<String, String>? {
        if (!autocorrectOn() || !showSug() || !fieldOk()) return null
        val w = currentWord()
        if (w.isEmpty() || w != curWord || !isTypo || !confident || sugs.isEmpty()) return null
        if (w.lowercase() in ignored) return null
        if (w.length > 1 && w.all { it.isUpperCase() }) return null                 // acronyms like FPS
        if (w[0].isUpperCase() && !atSentenceStart(w)) return null                  // probably a name
        val rep = matchCase(w, sugs[0])
        if (rep == w) return null
        val ic = currentInputConnection ?: return null
        ic.beginBatchEdit()
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText(rep, 1)
        ic.endBatchEdit()
        typedBuf.setLength(0)
        return Pair(w, rep)
    }

    /** Backspace right after an autocorrect puts your original word back. */
    private fun revertCorrection(): Boolean {
        val c = lastCorrection ?: return false
        lastCorrection = null
        val ic = currentInputConnection ?: return false
        val expected = c.replacement + c.sepText
        val b = ic.getTextBeforeCursor(expected.length, 0)?.toString()
        if (b != null && b != expected) return false
        ic.beginBatchEdit()
        ic.deleteSurroundingText(expected.length, 0)
        ic.commitText(c.original, 1)
        ic.endBatchEdit()
        addIgnored(c.original)
        typedBuf.setLength(0); typedBuf.append(c.original)
        return true
    }

    // =====================  Key handling  =====================
    private fun sendKey(code: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun sendCtrl(code: Int, withShift: Boolean) {
        val ic = currentInputConnection ?: return
        var meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (withShift) meta = meta or KeyEvent.META_SHIFT_ON
        val t = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
    }

    private fun trackTyped(out: String) {
        if (out.length == 1 && (out[0].isLetter() || out[0] == '\'')) typedBuf.append(out)
        else typedBuf.setLength(0)
    }

    /** Text chosen from the long-press bubble or a flick-down. */
    fun commitAlt(text: String) {
        lastCorrection = null
        currentInputConnection?.commitText(text, 1)
        trackTyped(text)
        if (shift && !caps) { shift = false; refreshLabels() }
        afterEdit()
    }

    private fun onKey(k: K) {
        val ic = currentInputConnection ?: return
        if (k.type != Type.DELETE) lastCorrection = null
        when (k.type) {
            Type.CHAR -> {
                val out = when {
                    k.base[0].isLetter() -> if (shift || caps) k.base.uppercase() else k.base
                    else -> if (shift && k.top != null && !small) k.top else k.base
                }
                val isSep = out.length == 1 && out[0] in SEPARATORS
                val corr = if (isSep) maybeAutocorrect() else null
                ic.commitText(out, 1)
                if (corr != null) lastCorrection = Correction(corr.first, corr.second, out)
                trackTyped(out)
                if (shift && !caps) { shift = false; refreshLabels() }
            }
            Type.SPACE -> {
                val corr = maybeAutocorrect()
                ic.commitText(" ", 1)
                if (corr != null) lastCorrection = Correction(corr.first, corr.second, " ")
                typedBuf.setLength(0)
            }
            Type.DOTCOM -> { ic.commitText(".com", 1); typedBuf.setLength(0) }
            Type.TAB -> { ic.commitText("\t", 1); typedBuf.setLength(0) }
            Type.DELETE -> deleteOnce()
            Type.SHIFT -> {
                // tap = one capital, double-tap = caps lock, tap again = off
                val now = SystemClock.uptimeMillis()
                if (caps) { caps = false; shift = false }
                else if (shift && now - lastShiftTap < 400) { caps = true }
                else { shift = !shift }
                lastShiftTap = now
                refreshLabels()
            }
            Type.CAPS -> { caps = !caps; refreshLabels() }
            Type.LEFT -> sendKey(KeyEvent.KEYCODE_DPAD_LEFT)
            Type.RIGHT -> sendKey(KeyEvent.KEYCODE_DPAD_RIGHT)
            Type.GO -> {
                maybeAutocorrect()
                lastCorrection = null
                typedBuf.setLength(0)
                if (hasAction()) ic.performEditorAction(actionId()) else sendKey(KeyEvent.KEYCODE_ENTER)
            }
            Type.SYMBOLS -> {
                symbols = !symbols
                handler.post { rebuild() }
            }
            Type.HIDE -> hideAnimated()
            Type.EMOJI -> {
                emojiOpen = true
                handler.post { rebuild() }
            }
            Type.GLOBE -> switchKeyboard()
            Type.MIC, Type.INERT, Type.SPACER -> { /* TODO: voice input */ }
        }
        afterEdit()
    }

    private fun deleteOnce() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel.isNullOrEmpty()) {
            ic.deleteSurroundingText(1, 0)
            if (typedBuf.isNotEmpty()) typedBuf.setLength(typedBuf.length - 1)
        } else {
            ic.commitText("", 1)
            typedBuf.setLength(0)
        }
        afterEdit()
    }

    private var repeater: Runnable? = null

    fun startRepeatDelete() {
        if (revertCorrection()) { afterEdit(); return }
        lastCorrection = null
        deleteOnce()
        val r = object : Runnable {
            override fun run() { deleteOnce(); handler.postDelayed(this, 50) }
        }
        repeater = r
        handler.postDelayed(r, 400)
    }

    fun stopRepeatDelete() { repeater?.let { handler.removeCallbacks(it) }; repeater = null }

    private fun refreshLabels() {
        keyViews.forEach {
            it.shifted = shift || caps
            it.capsOn = caps
            it.active = (it.key.type == Type.CAPS && caps) || (it.key.type == Type.SHIFT && (shift || caps))
            it.invalidate()
        }
    }

    // =====================  Custom key view  =====================
    inner class KeyView(ctx: Context, val key: K, private val onClick: () -> Unit) : View(ctx) {
        var shifted = false
        var capsOn = false
        var active = false
        private var down = false
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
        private val isDark = key.type !in listOf(Type.CHAR, Type.SPACE, Type.DOTCOM)

        // press look: darkens instantly, fades back softly
        private var pressAmt = 0f
        private var pressAnim: ValueAnimator? = null
        private fun setPressedAnim(on: Boolean) {
            pressAnim?.cancel()
            if (on) {
                pressAmt = 1f
                invalidate()
            } else {
                pressAnim = ValueAnimator.ofFloat(pressAmt, 0f).apply {
                    duration = 240
                    interpolator = DecelerateInterpolator()
                    addUpdateListener { pressAmt = it.animatedValue as Float; invalidate() }
                    start()
                }
            }
        }

        // long-press bubble
        private val alts: List<String> = if (key.type == Type.CHAR) ALTERNATES[key.base] ?: emptyList() else emptyList()
        private var popup: PopupWindow? = null
        private var altView: AltView? = null
        private var popupLeft = 0
        private val longRun = Runnable { showAlts() }

        // flick down (small mode): types the tiny hint symbol
        private val flickText: String? =
            if (key.type == Type.CHAR && small) (key.hint ?: key.top) else null
        private var downY = 0f
        private var flicking = false

        private fun showAlts() {
            if (alts.isEmpty() || flicking) return
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val opts = alts.map {
                if (shifted) { val up = it.uppercase(); if (up.length == 1) up else it } else it
            }
            val cellW = height * 0.95f
            val cellH = height.toFloat()
            val av = AltView(context, opts, cellW, cellH, pal)
            val popW = (cellW * opts.size + 2 * av.pad).toInt()
            val popH = (cellH + 2 * av.pad).toInt()
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            val screenW = resources.displayMetrics.widthPixels
            val x = (loc[0] + width / 2 - popW / 2).coerceIn(0, maxOf(0, screenW - popW))
            val y = loc[1] - popH - (height * 0.1f).toInt()
            val pw = PopupWindow(av, popW, popH, false)
            pw.isTouchable = false
            pw.isClippingEnabled = false
            pw.showAtLocation(this, Gravity.NO_GRAVITY, x, y)
            popup = pw; altView = av; popupLeft = x
        }

        private fun dismissPopup() {
            handler.removeCallbacks(longRun)
            popup?.dismiss()
            popup = null; altView = null
        }

        override fun onDraw(c: Canvas) {
            if (key.type == Type.SPACER) return
            val w = width.toFloat()
            val h = height.toFloat()
            val r = if (small) h * 0.07f else h * 0.08f     // small mode: less rounded
            val lip = h * 0.012f

            shadow.color = withAlpha(pal.shadow, pal.keyAlpha)
            c.drawRoundRect(0f, lip, w, h, r, r, shadow)

            val goBlue = key.type == Type.GO && (!small || hasAction())
            val baseFace = when {
                goBlue -> KEY_GO
                active -> pal.keyLight
                isDark -> pal.keyDark
                else -> pal.keyLight
            }
            val face = if (pressAmt > 0f) blend(baseFace, Color.BLACK, 0.30f * pressAmt) else baseFace
            bg.color = withAlpha(face, pal.keyAlpha)
            c.drawRoundRect(0f, 0f, w, h - lip, r, r, bg)

            txt.color = pal.text
            when {
                key.type == Type.CHAR && key.top != null -> {
                    txt.textSize = h * 0.27f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.top, w / 2, h * 0.38f, txt)
                    c.drawText(key.base, w / 2, h * 0.80f, txt)
                }
                key.type == Type.CHAR -> {
                    txt.textSize = h * 0.42f; txt.textAlign = Paint.Align.CENTER
                    val s = if (shifted && key.base[0].isLetter()) key.base.uppercase() else key.base
                    c.drawText(s, w / 2, h / 2 - (txt.ascent() + txt.descent()) / 2, txt)
                    if (small && key.hint != null) {
                        // tiny symbol on top (flick down to type it)
                        txt.textSize = h * 0.16f
                        txt.color = (pal.text and 0x00FFFFFF) or ((140 + (115 * pressAmt).toInt()) shl 24)
                        c.drawText(key.hint, w / 2, h * 0.30f, txt)
                    }
                }
                key.type == Type.SPACE || key.type == Type.INERT -> {}
                key.type == Type.LEFT || key.type == Type.RIGHT -> {
                    txt.textSize = h * 0.45f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.base, w / 2, h / 2 - (txt.ascent() + txt.descent()) / 2, txt)
                }
                key.type == Type.DOTCOM -> {
                    txt.textSize = h * 0.22f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.base, w / 2, h / 2 - (txt.ascent() + txt.descent()) / 2 - h * 0.04f, txt)
                }
                key.type == Type.SHIFT && small ->
                    drawIcon(c, Icon.SHIFT, w / 2, h / 2, h * 0.42f, pal.text, face, on = active, bar = capsOn)
                key.type == Type.DELETE && small ->
                    drawIcon(c, Icon.BACKSPACE, w / 2, h / 2, h * 0.46f, pal.text, face)
                key.type == Type.GLOBE ->
                    drawIcon(c, Icon.GLOBE, w / 2, h / 2, h * 0.40f, pal.text, face)
                key.type == Type.EMOJI ->
                    if (small) drawIcon(c, Icon.SMILEY, w / 2, h / 2, h * 0.42f, pal.text, face)
                    else drawIcon(c, Icon.SMILEY, h * 0.38f, h * 0.68f, h * 0.36f, pal.text, face)
                key.type == Type.MIC ->
                    if (small) drawIcon(c, Icon.MIC, w / 2, h / 2, h * 0.42f, pal.text, face)
                    else drawIcon(c, Icon.MIC, h * 0.38f, h * 0.68f, h * 0.36f, pal.text, face)
                key.type == Type.HIDE ->
                    if (small) drawIcon(c, Icon.KEYBOARD, w / 2, h / 2, h * 0.46f, pal.text, face)
                    else drawIcon(c, Icon.KEYBOARD, w - h * 0.38f, h * 0.64f, h * 0.40f, pal.text, face)
                else -> {
                    val label = if (key.type == Type.GO && small) goLabel() else key.base
                    txt.textSize = h * (if (small) 0.24f else 0.21f)
                    txt.color = if (goBlue) Color.WHITE else pal.text
                    val m = h * 0.15f
                    val y = if (key.align == Align.CENTER) h / 2 - (txt.ascent() + txt.descent()) / 2 else h - h * 0.15f
                    when (key.align) {
                        Align.LEFT -> { txt.textAlign = Paint.Align.LEFT; c.drawText(label, m, y, txt) }
                        Align.RIGHT -> { txt.textAlign = Paint.Align.RIGHT; c.drawText(label, w - m, y, txt) }
                        else -> { txt.textAlign = Paint.Align.CENTER; c.drawText(label, w / 2, y, txt) }
                    }
                }
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (key.type == Type.SPACER) return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    down = true; setPressedAnim(true)
                    downY = e.rawY; flicking = false
                    if (key.type == Type.DELETE) startRepeatDelete()
                    if (alts.isNotEmpty()) handler.postDelayed(longRun, 380)
                }
                MotionEvent.ACTION_MOVE -> {
                    val av = altView
                    if (av != null) {
                        val idx = ((e.rawX - popupLeft - av.pad) / av.cellW).toInt().coerceIn(0, av.opts.size - 1)
                        if (idx != av.selected) { av.selected = idx; av.invalidate() }
                    } else if (flickText != null) {
                        flicking = (e.rawY - downY) > height * 0.5f
                        if (flicking) handler.removeCallbacks(longRun)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    down = false; setPressedAnim(false)
                    handler.removeCallbacks(longRun)
                    val av = altView
                    if (av != null) {
                        commitAlt(av.opts[av.selected])
                        dismissPopup()
                    } else if (flicking && flickText != null) {
                        commitAlt(flickText)
                    } else if (key.type == Type.DELETE) {
                        stopRepeatDelete()
                    } else {
                        onClick()
                    }
                    flicking = false
                }
                MotionEvent.ACTION_CANCEL -> {
                    down = false; setPressedAnim(false)
                    dismissPopup()
                    flicking = false
                    if (key.type == Type.DELETE) stopRepeatDelete()
                }
            }
            return true
        }
    }
}
