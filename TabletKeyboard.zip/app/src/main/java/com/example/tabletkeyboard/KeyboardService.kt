package com.example.tabletkeyboard

import android.content.Context
import android.graphics.*
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

// ---------- Colors sampled from the reference image ----------
private val BG_KEYBOARD = Color.parseColor("#D1D3D9")
private val BG_TOOLBAR = Color.parseColor("#DCDDE2")
private val KEY_LIGHT = Color.WHITE
private val KEY_DARK = Color.parseColor("#B9BDC8")
private val KEY_GO = Color.parseColor("#0A84FF")
private val KEY_PRESSED = Color.parseColor("#9EA3B0")

enum class Type { CHAR, DELETE, TAB, CAPS, SHIFT, GO, SPACE, SYMBOLS, EMOJI, MIC, HIDE, DOTCOM }
enum class Align { CENTER, LEFT, RIGHT }

data class K(
    val base: String,
    val top: String? = null,       // shifted symbol shown above the base (two-line keys)
    val weight: Float = 1f,
    val type: Type = Type.CHAR,
    val align: Align = Align.CENTER
)

private fun letters(s: String) = s.map { K(it.toString()) }

class KeyboardService : InputMethodService() {

    private var shift = false
    private var caps = false
    private val keyViews = mutableListOf<KeyView>()
    private val handler = Handler(Looper.getMainLooper())

    // ---------- Layout definition (weights match the screenshot) ----------
    private val rows: List<List<K>> = listOf(
        // Row 1: number row
        listOf(
            K("`", "~"), K("1", "!"), K("2", "@"), K("3", "#"), K("4", "$"), K("5", "%"),
            K("6", "^"), K("7", "&"), K("8", "*"), K("9", "("), K("0", ")"),
            K("-", "_"), K("=", "+"),
            K("delete", weight = 1.6f, type = Type.DELETE, align = Align.RIGHT)
        ),
        // Row 2
        listOf(K("tab", weight = 1.6f, type = Type.TAB, align = Align.LEFT)) +
            letters("qwertyuiop") +
            listOf(K("[", "{"), K("]", "}"), K("\\", "|")),
        // Row 3
        listOf(K("caps lock", weight = 1.85f, type = Type.CAPS, align = Align.LEFT)) +
            letters("asdfghjkl") +
            listOf(K(";", ":"), K("'", "\""),
                K("go", weight = 1.85f, type = Type.GO, align = Align.RIGHT)),
        // Row 4
        listOf(K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.LEFT)) +
            letters("zxcvbnm") +
            listOf(K(",", "<"), K(".", ">"), K("/", "?"),
                K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.RIGHT)),
        // Row 5
        listOf(
            K("😀", weight = 1.5f, type = Type.EMOJI, align = Align.LEFT),
            K(".?123", weight = 1.5f, type = Type.SYMBOLS, align = Align.LEFT),
            K("🎤", weight = 1.5f, type = Type.MIC, align = Align.LEFT),
            K(" ", weight = 7f, type = Type.SPACE),
            K(".com", weight = 1f, type = Type.DOTCOM),
            K(".?123", weight = 1.5f, type = Type.SYMBOLS, align = Align.RIGHT),
            K("⌨", weight = 1.5f, type = Type.HIDE, align = Align.RIGHT)
        )
    )

    override fun onCreateInputView(): View {
        keyViews.clear()
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG_KEYBOARD)
        }

        // ----- Toolbar: cut / copy / paste -----
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(BG_TOOLBAR)
            setPadding((14 * dp).toInt(), 0, 0, 0)
        }
        fun tool(icon: String, action: Int) = TextView(this).apply {
            text = icon
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = android.view.Gravity.CENTER
            setPadding((10 * dp).toInt(), 0, (10 * dp).toInt(), 0)
            setOnClickListener { currentInputConnection?.performContextMenuAction(action) }
        }
        toolbar.addView(tool("✂", android.R.id.cut))
        toolbar.addView(tool("⧉", android.R.id.copy))
        toolbar.addView(tool("📋", android.R.id.paste))
        root.addView(toolbar, LinearLayout.LayoutParams(-1, (44 * dp).toInt()))

        // ----- Key rows -----
        val pad = (4 * dp).toInt()
        val keysContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        for (row in rows) {
            val rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in row) {
                val v = KeyView(this, k) { onKey(k) }
                keyViews.add(v)
                rowLayout.addView(
                    v,
                    LinearLayout.LayoutParams(0, -1, k.weight).apply {
                        setMargins((2.5f * dp).toInt(), (2.5f * dp).toInt(), (2.5f * dp).toInt(), (2.5f * dp).toInt())
                    }
                )
            }
            keysContainer.addView(rowLayout, LinearLayout.LayoutParams(-1, (62 * dp).toInt()))
        }
        root.addView(keysContainer, LinearLayout.LayoutParams(-1, -2))
        refreshLabels()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Show the right action label on the blue key (go/search/send/done...)
        shift = false; caps = false
        refreshLabels()
    }

    // ---------- Key handling ----------
    private fun onKey(k: K) {
        val ic = currentInputConnection ?: return
        when (k.type) {
            Type.CHAR -> {
                val out = when {
                    k.base[0].isLetter() -> if (shift || caps) k.base.uppercase() else k.base
                    else -> if (shift && k.top != null) k.top else k.base
                }
                ic.commitText(out, 1)
                if (shift && !caps) { shift = false; refreshLabels() }
            }
            Type.SPACE -> ic.commitText(" ", 1)
            Type.DOTCOM -> ic.commitText(".com", 1)
            Type.TAB -> ic.commitText("\t", 1)
            Type.DELETE -> deleteOnce()
            Type.SHIFT -> { shift = !shift; refreshLabels() }
            Type.CAPS -> { caps = !caps; refreshLabels() }
            Type.GO -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                if (action != null && action != EditorInfo.IME_ACTION_NONE &&
                    action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.performEditorAction(action)
                } else {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                }
            }
            Type.HIDE -> requestHideSelf(0)
            Type.SYMBOLS, Type.EMOJI, Type.MIC -> { /* TODO: symbols page, emoji picker, voice input */ }
        }
    }

    private fun deleteOnce() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel.isNullOrEmpty()) ic.deleteSurroundingText(1, 0) else ic.commitText("", 1)
    }

    /** Called by the delete key while it's held down. */
    fun startRepeatDelete() {
        deleteOnce()
        handler.postDelayed(object : Runnable {
            override fun run() { deleteOnce(); handler.postDelayed(this, 50) }
        }.also { repeater = it }, 400)
    }
    private var repeater: Runnable? = null
    fun stopRepeatDelete() { repeater?.let { handler.removeCallbacks(it) }; repeater = null }

    private fun refreshLabels() {
        keyViews.forEach { it.shifted = shift || caps; it.active = (it.key.type == Type.CAPS && caps) || (it.key.type == Type.SHIFT && shift); it.invalidate() }
    }

    // ---------- Custom key view ----------
    inner class KeyView(ctx: Context, val key: K, private val onClick: () -> Unit) : View(ctx) {
        var shifted = false
        var active = false
        private var down = false
        private val d = resources.displayMetrics.density
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#898A8D") }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        private val isDark = key.type !in listOf(Type.CHAR, Type.SPACE, Type.DOTCOM)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat(); val r = 6 * d
            // subtle bottom shadow, then key face
            c.drawRoundRect(0f, 1.2f * d, w, h, r, r, shadow)
            bg.color = when {
                down -> KEY_PRESSED
                key.type == Type.GO -> KEY_GO
                active -> KEY_LIGHT
                isDark -> KEY_DARK
                else -> KEY_LIGHT
            }
            c.drawRoundRect(0f, 0f, w, h - 1.2f * d, r, r, bg)

            val fm = txt.fontMetrics
            when {
                key.type == Type.CHAR && key.top != null -> {
                    // Two-line key: shifted symbol on top, base below
                    txt.textSize = 17 * d; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.top, w / 2, h * 0.42f, txt)
                    c.drawText(key.base, w / 2, h * 0.80f, txt)
                }
                key.type == Type.CHAR -> {
                    txt.textSize = 26 * d; txt.textAlign = Paint.Align.CENTER
                    val s = if (shifted) key.base.uppercase() else key.base
                    c.drawText(s, w / 2, h / 2 - (fm.ascent + fm.descent) / 2, txt)
                }
                key.type == Type.SPACE -> {}
                key.type == Type.DOTCOM -> {
                    txt.textSize = 16 * d; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.base, w / 2, h / 2 - (fm.ascent + fm.descent) / 2 - 4 * d, txt)
                }
                else -> {
                    // Modifier keys: small label in the bottom corner
                    txt.textSize = 16 * d
                    txt.color = if (key.type == Type.GO) Color.WHITE else Color.BLACK
                    val y = h - 12 * d
                    when (key.align) {
                        Align.LEFT -> { txt.textAlign = Paint.Align.LEFT; c.drawText(key.base, 12 * d, y, txt) }
                        Align.RIGHT -> { txt.textAlign = Paint.Align.RIGHT; c.drawText(key.base, w - 12 * d, y, txt) }
                        else -> { txt.textAlign = Paint.Align.CENTER; c.drawText(key.base, w / 2, y, txt) }
                    }
                    txt.color = Color.BLACK
                }
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    down = true; invalidate()
                    if (key.type == Type.DELETE) startRepeatDelete()
                }
                MotionEvent.ACTION_UP -> {
                    down = false; invalidate()
                    if (key.type == Type.DELETE) stopRepeatDelete() else onClick()
                }
                MotionEvent.ACTION_CANCEL -> {
                    down = false; invalidate()
                    if (key.type == Type.DELETE) stopRepeatDelete()
                }
            }
            return true
        }
    }
}
