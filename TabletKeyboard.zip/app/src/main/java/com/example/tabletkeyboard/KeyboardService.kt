package com.example.tabletkeyboard

import android.content.Context
import android.graphics.*
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout

// ---------- Colors sampled from the reference image ----------
private val BG_KEYBOARD = Color.parseColor("#D1D3D9")
private val BG_TOOLBAR = Color.parseColor("#DCDDE2")
private val KEY_LIGHT = Color.WHITE
private val KEY_DARK = Color.parseColor("#B9BDC8")
private val KEY_GO = Color.parseColor("#0A84FF")
private val KEY_PRESSED = Color.parseColor("#9EA3B0")

enum class Type { CHAR, DELETE, TAB, CAPS, SHIFT, GO, SPACE, SYMBOLS, EMOJI, MIC, HIDE, DOTCOM }
enum class Align { CENTER, LEFT, RIGHT }
enum class Icon { SMILEY, MIC, KEYBOARD, SCISSORS, COPY, PASTE }

data class K(
    val base: String,
    val top: String? = null,       // shifted symbol shown above the base (two-line keys)
    val weight: Float = 1f,
    val type: Type = Type.CHAR,
    val align: Align = Align.CENTER
)

private fun letters(s: String) = s.map { K(it.toString()) }

// ---------- Black outline icons drawn with Canvas ----------
fun drawIcon(c: Canvas, icon: Icon, cx: Float, cy: Float, size: Float) {
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.BLACK
        strokeWidth = size * 0.075f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.BLACK }
    val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#E8E9EE") }
    val r = size / 2f
    when (icon) {
        Icon.SMILEY -> {
            c.drawCircle(cx, cy, r * 0.9f, stroke)
            c.drawCircle(cx - r * 0.32f, cy - r * 0.2f, r * 0.09f, fill)
            c.drawCircle(cx + r * 0.32f, cy - r * 0.2f, r * 0.09f, fill)
            c.drawArc(RectF(cx - r * 0.5f, cy - r * 0.35f, cx + r * 0.5f, cy + r * 0.55f), 20f, 140f, false, stroke)
        }
        Icon.MIC -> {
            c.drawRoundRect(RectF(cx - r * 0.28f, cy - r * 0.95f, cx + r * 0.28f, cy + r * 0.2f), r * 0.28f, r * 0.28f, stroke)
            c.drawArc(RectF(cx - r * 0.6f, cy - r * 0.45f, cx + r * 0.6f, cy + r * 0.55f), 0f, 180f, false, stroke)
            c.drawLine(cx, cy + r * 0.55f, cx, cy + r * 0.95f, stroke)
        }
        Icon.KEYBOARD -> {
            c.drawRoundRect(RectF(cx - r, cy - r * 0.7f, cx + r, cy + r * 0.2f), r * 0.12f, r * 0.12f, stroke)
            for (i in 0..4) {
                val x = cx - r * 0.65f + i * r * 0.325f
                c.drawCircle(x, cy - r * 0.45f, r * 0.05f, fill)
                c.drawCircle(x, cy - r * 0.2f, r * 0.05f, fill)
            }
            c.drawLine(cx - r * 0.5f, cy, cx + r * 0.5f, cy, stroke)
            val p = Path()
            p.moveTo(cx - r * 0.25f, cy + r * 0.5f); p.lineTo(cx, cy + r * 0.75f); p.lineTo(cx + r * 0.25f, cy + r * 0.5f)
            c.drawPath(p, stroke)
        }
        Icon.SCISSORS -> {
            c.drawCircle(cx - r * 0.55f, cy + r * 0.55f, r * 0.25f, stroke)
            c.drawCircle(cx + r * 0.55f, cy + r * 0.55f, r * 0.25f, stroke)
            c.drawLine(cx - r * 0.4f, cy + r * 0.35f, cx + r * 0.85f, cy - r * 0.8f, stroke)
            c.drawLine(cx + r * 0.4f, cy + r * 0.35f, cx - r * 0.85f, cy - r * 0.8f, stroke)
        }
        Icon.COPY -> {
            c.drawRoundRect(RectF(cx - r * 0.75f, cy - r * 0.85f, cx + r * 0.2f, cy + r * 0.35f), r * 0.12f, r * 0.12f, stroke)
            c.drawRoundRect(RectF(cx - r * 0.2f, cy - r * 0.35f, cx + r * 0.75f, cy + r * 0.85f), r * 0.12f, r * 0.12f, stroke)
        }
        Icon.PASTE -> {
            c.drawRoundRect(RectF(cx - r * 0.7f, cy - r * 0.75f, cx + r * 0.7f, cy + r * 0.95f), r * 0.15f, r * 0.15f, fill)
            c.drawRoundRect(RectF(cx - r * 0.45f, cy - r * 0.4f, cx + r * 0.45f, cy + r * 0.75f), r * 0.08f, r * 0.08f, white)
            c.drawRoundRect(RectF(cx - r * 0.3f, cy - r * 0.95f, cx + r * 0.3f, cy - r * 0.5f), r * 0.1f, r * 0.1f, fill)
        }
    }
}

class IconView(ctx: Context, private val icon: Icon, private val onTap: () -> Unit) : View(ctx) {
    init { setOnClickListener { onTap() } }
    override fun onDraw(c: Canvas) {
        drawIcon(c, icon, width / 2f, height / 2f, minOf(width, height) * 0.6f)
    }
}

class KeyboardService : InputMethodService() {

    private var shift = false
    private var caps = false
    private val keyViews = mutableListOf<KeyView>()
    private val handler = Handler(Looper.getMainLooper())

    // ---------- Layout definition (weights match the screenshot) ----------
    private val rows: List<List<K>> = listOf(
        // Row 1: number row
        listOf(
            K("`", "~"), K("1", "!"), K("2", "@"), K("3", "#"), K("4", "$"), K("5", "%"),
            K("6", "^"), K("7", "&"), K("8", "*"), K("9", "("), K("0", ")"),
            K("-", "_"), K("=", "+"),
            K("delete", weight = 1.6f, type = Type.DELETE, align = Align.RIGHT)
        ),
        // Row 2
        listOf(K("tab", weight = 1.6f, type = Type.TAB, align = Align.LEFT)) +
            letters("qwertyuiop") +
            listOf(K("[", "{"), K("]", "}"), K("\\", "|")),
        // Row 3
        listOf(K("caps lock", weight = 1.85f, type = Type.CAPS, align = Align.LEFT)) +
            letters("asdfghjkl") +
            listOf(K(";", ":"), K("'", "\""),
                K("go", weight = 1.85f, type = Type.GO, align = Align.RIGHT)),
        // Row 4
        listOf(K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.LEFT)) +
            letters("zxcvbnm") +
            listOf(K(",", "<"), K(".", ">"), K("/", "?"),
                K("shift", weight = 2.4f, type = Type.SHIFT, align = Align.RIGHT)),
        // Row 5
        listOf(
            K("", weight = 1.5f, type = Type.EMOJI, align = Align.LEFT),
            K(".?123", weight = 1.5f, type = Type.SYMBOLS, align = Align.LEFT),
            K("", weight = 1.5f, type = Type.MIC, align = Align.LEFT),
            K(" ", weight = 7f, type = Type.SPACE),
            K(".com", weight = 1f, type = Type.DOTCOM),
            K(".?123", weight = 1.5f, type = Type.SYMBOLS, align = Align.RIGHT),
            K("", weight = 1.5f, type = Type.HIDE, align = Align.RIGHT)
        )
    )

    override fun onCreateInputView(): View {
        keyViews.clear()
        val dm = resources.displayMetrics
        val dp = dm.density
        val screenW = dm.widthPixels.toFloat()

        // Everything scales with the screen width, like the reference image
        val rowH = maxOf(screenW * 0.0646f, 48 * dp).toInt()
        val toolbarH = maxOf(screenW * 0.040f, 40 * dp).toInt()
        val gap = maxOf(screenW * 0.0034f, 2 * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG_KEYBOARD)
        }

        // ----- Toolbar: cut / copy / paste -----
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(BG_TOOLBAR)
            setPadding(gap * 3, 0, 0, 0)
        }
        fun tool(icon: Icon, action: Int) =
            IconView(this, icon) { currentInputConnection?.performContextMenuAction(action) }
        val toolW = (toolbarH * 1.3f).toInt()
        toolbar.addView(tool(Icon.SCISSORS, android.R.id.cut), LinearLayout.LayoutParams(toolW, -1))
        toolbar.addView(tool(Icon.COPY, android.R.id.copy), LinearLayout.LayoutParams(toolW, -1))
        toolbar.addView(tool(Icon.PASTE, android.R.id.paste), LinearLayout.LayoutParams(toolW, -1))
        root.addView(toolbar, LinearLayout.LayoutParams(-1, toolbarH))

        // ----- Key rows -----
        val keysContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(gap, gap, gap, gap)
        }
        for (row in rows) {
            val rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in row) {
                val v = KeyView(this, k) { onKey(k) }
                keyViews.add(v)
                rowLayout.addView(
                    v,
                    LinearLayout.LayoutParams(0, -1, k.weight).apply { setMargins(gap, gap, gap, gap) }
                )
            }
            keysContainer.addView(rowLayout, LinearLayout.LayoutParams(-1, rowH))
        }
        root.addView(keysContainer, LinearLayout.LayoutParams(-1, -2))
        refreshLabels()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false; caps = false
        refreshLabels()
    }

    // ---------- Key handling ----------
    private fun onKey(k: K) {
        val ic = currentInputConnection ?: return
        when (k.type) {
            Type.CHAR -> {
                val out = when {
                    k.base[0].isLetter() -> if (shift || caps) k.base.uppercase() else k.base
                    else -> if (shift && k.top != null) k.top else k.base
                }
                ic.commitText(out, 1)
                if (shift && !caps) { shift = false; refreshLabels() }
            }
            Type.SPACE -> ic.commitText(" ", 1)
            Type.DOTCOM -> ic.commitText(".com", 1)
            Type.TAB -> ic.commitText("\t", 1)
            Type.DELETE -> deleteOnce()
            Type.SHIFT -> { shift = !shift; refreshLabels() }
            Type.CAPS -> { caps = !caps; refreshLabels() }
            Type.GO -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                if (action != null && action != EditorInfo.IME_ACTION_NONE &&
                    action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.performEditorAction(action)
                } else {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                }
            }
            Type.HIDE -> requestHideSelf(0)
            Type.SYMBOLS, Type.EMOJI, Type.MIC -> { /* TODO: symbols page, emoji picker, voice input */ }
        }
    }

    private fun deleteOnce() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel.isNullOrEmpty()) ic.deleteSurroundingText(1, 0) else ic.commitText("", 1)
    }

    private var repeater: Runnable? = null

    fun startRepeatDelete() {
        deleteOnce()
        val r = object : Runnable {
            override fun run() { deleteOnce(); handler.postDelayed(this, 50) }
        }
        repeater = r
        handler.postDelayed(r, 400)
    }

    fun stopRepeatDelete() { repeater?.let { handler.removeCallbacks(it) }; repeater = null }

    private fun refreshLabels() {
        keyViews.forEach {
            it.shifted = shift || caps
            it.active = (it.key.type == Type.CAPS && caps) || (it.key.type == Type.SHIFT && shift)
            it.invalidate()
        }
    }

    // ---------- Custom key view ----------
    inner class KeyView(ctx: Context, val key: K, private val onClick: () -> Unit) : View(ctx) {
        var shifted = false
        var active = false
        private var down = false
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#898A8D") }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        private val isDark = key.type !in listOf(Type.CHAR, Type.SPACE, Type.DOTCOM)

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val r = h * 0.08f
            val lip = h * 0.012f

            // subtle bottom edge, then key face
            c.drawRoundRect(0f, lip, w, h, r, r, shadow)
            bg.color = when {
                down -> KEY_PRESSED
                key.type == Type.GO -> KEY_GO
                active -> KEY_LIGHT
                isDark -> KEY_DARK
                else -> KEY_LIGHT
            }
            c.drawRoundRect(0f, 0f, w, h - lip, r, r, bg)

            val fm = txt.fontMetrics
            when {
                key.type == Type.CHAR && key.top != null -> {
                    // Two-line key: shifted symbol on top, base below
                    txt.textSize = h * 0.27f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.top, w / 2, h * 0.38f, txt)
                    c.drawText(key.base, w / 2, h * 0.80f, txt)
                }
                key.type == Type.CHAR -> {
                    txt.textSize = h * 0.42f; txt.textAlign = Paint.Align.CENTER
                    val s = if (shifted) key.base.uppercase() else key.base
                    c.drawText(s, w / 2, h / 2 - (fm.ascent + fm.descent) / 2, txt)
                }
                key.type == Type.SPACE -> {}
                key.type == Type.DOTCOM -> {
                    txt.textSize = h * 0.22f; txt.textAlign = Paint.Align.CENTER
                    c.drawText(key.base, w / 2, h / 2 - (fm.ascent + fm.descent) / 2 - h * 0.04f, txt)
                }
                key.type == Type.EMOJI -> drawIcon(c, Icon.SMILEY, h * 0.38f, h * 0.68f, h * 0.36f)
                key.type == Type.MIC -> drawIcon(c, Icon.MIC, h * 0.38f, h * 0.68f, h * 0.36f)
                key.type == Type.HIDE -> drawIcon(c, Icon.KEYBOARD, w - h * 0.38f, h * 0.64f, h * 0.40f)
                else -> {
                    // Modifier keys: small label in the bottom corner
                    txt.textSize = h * 0.21f
                    txt.color = if (key.type == Type.GO) Color.WHITE else Color.BLACK
                    val y = h - h * 0.15f
                    val m = h * 0.15f
                    when (key.align) {
                        Align.LEFT -> { txt.textAlign = Paint.Align.LEFT; c.drawText(key.base, m, y, txt) }
                        Align.RIGHT -> { txt.textAlign = Paint.Align.RIGHT; c.drawText(key.base, w - m, y, txt) }
                        else -> { txt.textAlign = Paint.Align.CENTER; c.drawText(key.base, w / 2, y, txt) }
                    }
                    txt.color = Color.BLACK
                }
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    down = true; invalidate()
                    if (key.type == Type.DELETE) startRepeatDelete()
                }
                MotionEvent.ACTION_UP -> {
                    down = false; invalidate()
                    if (key.type == Type.DELETE) stopRepeatDelete() else onClick()
                }
                MotionEvent.ACTION_CANCEL -> {
                    down = false; invalidate()
                    if (key.type == Type.DELETE) stopRepeatDelete()
                }
            }
            return true
        }
    }
}
