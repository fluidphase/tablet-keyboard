# Tablet Keyboard (Android IME)

## Setup
1. In Android Studio: New Project > "Empty Views Activity" (Kotlin), package `com.example.tabletkeyboard`.
2. Copy `KeyboardService.kt` into the package folder, and merge the `<service>` block from
   `AndroidManifest.xml` and the `res/xml/method.xml` file into your project.
   (An IME needs no Activity, but Android Studio wants one for the first run; you can leave it.)
3. Run on a tablet or tablet emulator.
4. Settings > System > Languages & input > On-screen keyboard > Manage keyboards > enable "Tablet Keyboard".
5. Tap any text field, then pick it from the keyboard switcher.

## Still to do
- `.?123` symbols page, emoji picker, voice input (marked TODO in code)
- Replace the text icons (✂ ⧉ 📋 🎤 ⌨) with vector drawables for an exact match
- Swap the font for one close to SF Pro (e.g. Inter) if you want the iOS look
- Suggestions bar / autocorrect
